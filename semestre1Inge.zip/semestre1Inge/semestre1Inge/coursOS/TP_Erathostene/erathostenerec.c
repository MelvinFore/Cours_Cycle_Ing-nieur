#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <signal.h>

int catch=0;

// Routine de gestion de SIGINT
void	sigint_handler(int signal)
{
	if (signal == SIGINT)
    catch=1;
}

void set_signal_action(void)
{
	// Déclaration de la structure sigaction
	struct sigaction	act;

	// Met à 0 tous les bits dans la structure,

	bzero(&act, sizeof(act));


	act.sa_handler = &sigint_handler;
	// Applique cette structure avec la fonction à invoquer
	// au signal SIGINT (ctrl-c)
	sigaction(SIGINT, &act, NULL);
}

int filtre_rec(int fnum,int descripPipe)
{
  int filtre[2];
  int num;
  int newNumber=0;
  if(pipe(filtre)==-1){
    fprintf(stderr, "Erreur : la creation du pipe à echoue") ;
    return 1 ; // sortie du programme
  }
  //On ferme l'entree standard
  close(0);
  dup(descripPipe);
  while (read(0,&num,sizeof(int))){
    //quand -1 est lu on affiche le nombre premier,on envoie -1 au processus fils et on attend son arret
    if(num==-1){
      printf("%d\n",fnum);
      write(filtre[1],&num,sizeof(int));
      break;
    }
    //si num%fnum!=0 on envoie dans le pipe du processus fils
    if(num%fnum!=0){
      //Si c'est la premiere valeur on cree un procussus fils qui pourra lire les valeurs suivante par le pipe, on sait des lors que num est premier
      if(newNumber==0){
        newNumber=1;
        if(!fork()){
          close(filtre[1]);
          filtre_rec(num,filtre[0]);
          break;
        }
        close(filtre[0]);
      }
      write(filtre[1],&num,sizeof(int));
    }
  }
  wait(NULL);
}

int main(){
    int cpy0;
    int fd[2];
    int num;
    //fnum permettra de stocker est d'afficher chaque nombre premier que notre chaine de filtre trouvera
    int fnum=-1;

      //on cree le pipe
      if(pipe(fd)==-1){
        fprintf(stderr, "Erreur : la creation du pipe à echoue") ;
        return 1 ; // sortie du programme
      }
      set_signal_action();
      //On duplique notre processus
      if(fork()){
        //le pere de tous nos futurs processus incrementera une variable num et enverra les valeurs par un pipe
        close(fd[0]);
        num=2;
        while(num){
              write(fd[1],&num,sizeof(int));
            num++;
            //si un sigint est detecte on envoie -1 pour indiquer aux fils d'arreter, ils finiront quand même de traiter les valeurs transmise avant l'envoie du -1
            if(catch==1){
              printf("arret\n");
              num=-1;
              //on ecrit dans le pipe
              write(fd[1],&num,sizeof(int));
              break;
            }
        }
        close(fd[1]);
      }else{
        close(fd[1]);
        //le descripteur pour lire dans le pipe est transmis à une fonction recussive
        filtre_rec(2,fd[0]);
    }
    wait(NULL);
    return 0;
}
