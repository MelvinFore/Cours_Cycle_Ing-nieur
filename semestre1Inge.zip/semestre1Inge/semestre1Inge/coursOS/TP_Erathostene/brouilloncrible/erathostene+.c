#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(){
    int cpy0;
    int fd[2];
    int num;
    int fnum=-1;
    int end=0;

      //on cree le pipe
      pipe(fd);

      //On duplique notre processus
      if(fork()){
        close(fd[0]);
        fnum=2;
        printf("2\n");
        for(num=2;num<200;num++){
            if(num%fnum!=0){
              write(fd[1],&num,sizeof(int));
            }
        }
        num=0;
        write(fd[1],&num,sizeof(int));
        close(fd[1]);
      }else{
        //On ferme l'entree standard
        close(0);
        dup(fd[0]);
        read(0,&num,sizeof(int));
        fnum=num;
        while(1){
          printf("%d\n",fnum);
          //On lit les informations envoye par le pere dans le pipe
          while (read(0,&num,sizeof(int))&&num!=0){
            if(num%fnum!=0){
              write(fd[1],&num,sizeof(int));
              if(end==0){
                if(!fork()){
                  fnum=0;
                  write(fd[1],&fnum,sizeof(int));
                  fnum=num;
                  printf("%d\n",fnum);
                  continue;
                }
                end=1;
              }
            }
          }
          close(fd[0]);
          close(fd[1]);
          break;
        }
    }
    wait(NULL);
}
