#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(){
    int cpy0;
    int fd[10000][2];
    int num;
    int fnum=-1;
    int end=0;
    int idP=0;

      //on cree le pipe
      pipe(fd[idP]);

      //On duplique notre processus
      if(fork()){
        close(fd[idP][0]);
        fnum=2;
        printf("2\n");
        num=2;
        while(num){
            if(num%fnum!=0){
              write(fd[idP][1],&num,sizeof(int));
            }
        num++;
        }
        close(fd[idP][1]);
      }else{
        //On ferme l'entree standard
        close(0);
        dup(fd[idP][0]);
        read(0,&num,sizeof(int));
        fnum=num;
        while(1){
          close(0);
          dup(fd[idP][0]);
          close(fd[idP][1]);
          idP=idP+1;
          pipe(fd[idP]);
          printf("=%d\n",fnum);


          while (read(0,&num,sizeof(int))){
            if(num%fnum!=0){
              write(fd[idP][1],&num,sizeof(int));
              if(end==0){
                if(!fork()){
                  end=1;
                  fnum=num;
                  break;
                }
                end=-1;
              }
            }
          }
          if(end==1){
            end=0;
            continue;
          }
          close(fd[idP-1][0]);
          close(fd[idP][0]);
          close(fd[idP][1]);
          break;
        }
    }
  //  printf("end=%d\n",fnum);
    wait(NULL);
}
