#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(){
    int fdS;
    int cpy0;
    int fd[2];

      //on cree le pipe
      pipe(fd);

      //On duplique notre processus
      if(!fork()){
        close(fd[0]);
        close(1);
        dup(fd[1]);
        execl("/bin/ls","ls", NULL);
        close(fd[1]);
      }else{
          close(fd[1]);
          close(0);
          dup(fd[0]);
          execl("/bin/wc","wc","-l",NULL);
          close(fd[0]);
      }
 }
