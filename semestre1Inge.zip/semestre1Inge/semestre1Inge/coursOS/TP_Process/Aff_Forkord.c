#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

/*int main(void){
int ppid;
int n=8;
  for(int i=1;i<=8;i++){
    if(fork()){
      printf("%d\n",i);
      break;
    }else{
      ppid=getpid();
      printf("%d\n",ppid);
      waitpid(ppid,NULL,0);
    }
  }
  //wait(NULL);
  return 0;
}*/

int main(){
  int n=8;
  int pid;
  for(int i=1;i<=n;i++){
    pid=fork();
    if(!pid){
      printf("%d\n",i);
      break;
    }
    wait(NULL);
  }
  return 0;
}
