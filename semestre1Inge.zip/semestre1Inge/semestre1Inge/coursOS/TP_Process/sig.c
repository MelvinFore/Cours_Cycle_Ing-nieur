#include <signal.h>
#include <stdio.h>
#include <strings.h>

// Routine de gestion de SIGINT
void	sigint_handler(int signal)
{
	if (signal == SIGINT)
		printf("\nIntercepted SIGINT!\n");
}

void set_signal_action(void)
{
	// Déclaration de la structure sigaction
	struct sigaction	act;

	// Met à 0 tous les bits dans la structure,

	bzero(&act, sizeof(act));


	act.sa_handler = &sigint_handler;
	// Applique cette structure avec la fonction à invoquer
	// au signal SIGINT (ctrl-c)
	sigaction(SIGINT, &act, NULL);
}

int	main(void)
{
	// Change l'action associée à SIGINT
	set_signal_action();
	// Boucle infinie pour avoir le temps de faire ctrl-c autant
	// de fois que ça nous chante
	while(1)
		continue ;
	return (0);
}

//On peut faire ctrl\ pour quitter
//On ne peut pas rediriger sig stop et sigkill
