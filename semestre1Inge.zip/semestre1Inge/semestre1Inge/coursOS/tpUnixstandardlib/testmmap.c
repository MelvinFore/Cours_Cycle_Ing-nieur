#include <sys/mman.h>
 #include <sys/stat.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[]){
  int fdS;
  int fdC;
  void *mm;
  struct stat st;
  stat(argv[1], &st);
  fdS=open(argv[1],O_RDONLY);
  fdC=open(argv[2],O_CREAT|O_WRONLY,0777);
  //Le 1 er parametre null permet de laisser le systeme de trouver une zone memoire dispo
  //et aligne a la page!(l'adresse soit un multiple de la taille de la page)
  mm=mmap(NULL,st.st_size, PROT_READ, MAP_PRIVATE,fdS,0);
  write(fdC,mm,st.st_size);
  close(fdS);
  close(fdC);
  //permet de defaire la projection mémoire
  munmap(mm,st.st_size);
}
