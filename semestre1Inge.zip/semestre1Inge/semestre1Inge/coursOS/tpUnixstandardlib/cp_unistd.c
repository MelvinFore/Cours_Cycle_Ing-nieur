#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>

int main(int argc,char *argv[]){
  if(argc==3){
    int fdS;
    int fdC;
    char c;
    fdS=open(argv[1],O_RDONLY);
    fdC=open(argv[2],O_CREAT|O_WRONLY,0777);
    while(read(fdS,&c,sizeof(char))){
      write(fdC,&c,sizeof(char));
    }
    close(fdS);
    close(fdC);
  }
}
