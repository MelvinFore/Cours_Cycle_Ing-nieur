#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>

int cpt=0;

typedef struct
{
   pthread_mutex_t* mx1;
   pthread_cond_t* condProd;
   pthread_cond_t* condCons;
   int* flag;
   int* counter;
}personne;

void *cons(void *p) {
  personne* mcons=(personne*)p;
  while(1){
    pthread_mutex_lock(mcons->mx1);
    if(*(mcons->flag)==0){
      pthread_cond_wait(mcons->condCons,mcons->mx1);
    }
    printf("\nle thread %ld recupere la val %d\n",pthread_self(),*(mcons->counter));
    *(mcons->flag)=0;
    pthread_cond_signal(mcons->condProd);
    pthread_mutex_unlock(mcons->mx1);
  }
	return(NULL);
}

void *prod(void *p) {
  personne* mprod=(personne*)p;
  while(1){
    pthread_mutex_lock(mprod->mx1);
    if(*(mprod->flag)==1){
      pthread_cond_wait(mprod->condProd,mprod->mx1);
    }
    cpt++;
    *(mprod->counter)=*(mprod->counter)+1;
    *(mprod->flag)=1;
    printf("on envoie le sig\n");
    sleep(1);
    pthread_cond_signal(mprod->condCons);
    pthread_mutex_unlock(mprod->mx1);
  }
  return(NULL);
}

int main() {
  int nbpersonne;
  printf("renseignez un nombre de consommateur superieur à 2:");
  scanf("%d",&nbpersonne);
  printf("\n");
  if(nbpersonne>=2){
    int initCounter=0;
    int initFlag=0;
    pthread_mutex_t mx1;
    pthread_mutex_init(&mx1, NULL);
    pthread_cond_t ProdCondInit = PTHREAD_COND_INITIALIZER;
    pthread_cond_t ConsCondInit = PTHREAD_COND_INITIALIZER;
    //On rajoute le producteur
    nbpersonne++;
    personne strPersonne[nbpersonne];
    pthread_t t[nbpersonne];

    strPersonne[0].flag=&initFlag;
    strPersonne[0].counter=&initCounter;
    strPersonne[0].mx1=&mx1;
    strPersonne[0].condProd=&ProdCondInit;
    strPersonne[0].condCons=&ConsCondInit;
    pthread_create(&t[0], NULL, prod,(void *) &strPersonne[0]);

    for(int i=1;i<nbpersonne;i++){
      strPersonne[i].flag=&initFlag;
      strPersonne[i].counter=&initCounter;
      strPersonne[i].mx1=&mx1;
      strPersonne[i].condProd=&ProdCondInit;
      strPersonne[i].condCons=&ConsCondInit;
      pthread_create(&t[i], NULL, cons,(void *) &strPersonne[i]);
    }

    for(int i=0; i<nbpersonne;i++)
      pthread_join(t[i], NULL);
  }
	return(EXIT_SUCCESS);
}
