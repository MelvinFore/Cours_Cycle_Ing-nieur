#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>

typedef struct
{
   pthread_mutex_t* mx1;
   int ordre;
   int* sum;
   int p;
}valsum;

void *HelloThread(void *p) {
  valsum* mstruct=(valsum*)p;
    printf("Bonjour je suis %ld mon ordre de passage est %d\n",pthread_self(),mstruct->ordre);

    for(int i=0;i<mstruct->p;i++){
      pthread_mutex_lock(mstruct->mx1);
      *(mstruct->sum)=*(mstruct->sum)+mstruct->ordre;
      pthread_mutex_unlock(mstruct->mx1);
    }
	return(NULL);
}


int main(int argc, char *argv[]) {
  int sum;
  sum=0;
  if(argc>1){
    pthread_mutex_t mx1;
    pthread_mutex_init(&mx1, NULL);
    valsum mystruct[atoi(argv[1])];
    pthread_t t[atoi(argv[1])];
    for(int i=0; i<atoi(argv[1]);i++){
          mystruct[i].sum=&sum;
          mystruct[i].ordre=i;
          mystruct[i].mx1=&mx1;
          mystruct[i].p=rand() % 100;
          printf("la struct d'ordre %d devra incrementer son ordre %d fois\n",mystruct[i].ordre,mystruct[i].p);
          pthread_create(&t[i], NULL, HelloThread,(void *) &mystruct[i]);
    }

    // int pthread_join(pthread_t thread, void **retval);
    for(int i=0; i<atoi(argv[1]);i++)
      pthread_join(t[i], NULL);
  printf("La somme total est egale à %d\n",sum);
  }else{
    printf("Veuillez mettre un argument\n");
  }

	return(EXIT_SUCCESS);
}
