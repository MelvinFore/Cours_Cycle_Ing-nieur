#!/bin/bash
echo Nom du prog : $0
echo $1 $2
echo fin du prog
