#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "rapideuniqv1.h"


// Définition du type booleen
typedef int bool;

#define false 0
#define true 1

//A partir d un tableau de 3 cases, on sélection la valeur de la dernière case du tableau qui servira de pivot
//on crée 2 sous-tableaux, les valeurs inférieurs iront dans la partie gauche et celles égales ou superieures iront à droite
//on met le pivot dans la premieère case du tableau droite.
//on fait cela jusqu'à n'avoir que des tableaux de taille inférieure ou égale à 2 puis à la remonte récursive
//on reconstitue le tableau principal en mettant bout à bout le tableau de gauche et de droite
void tri_rapideuniqv1(int tab[],int taille)
{
  int tmp;

  //on gere le cas ou le tableau ne fait que deux cases
  if(taille==2){
    swap(tab,0,1);
  }else if(taille>2){
    rapideuniqv1(tab,0,taille-1);
  }

  return;
}


void rapideuniqv1(int tab[],int idDep, int idEnd){
  if((idEnd-idDep)>1){
    int pivot;
    pivot=aleapivot(tab,idDep,idEnd);
    pivot=reorgatab(tab,pivot,idDep,idEnd);
    if(pivot!=-1){
      rapideuniqv1(tab,idDep,pivot-1);
      rapideuniqv1(tab,pivot,idEnd);
    }
  }else if((idEnd-idDep)==1){
    if(tab[idDep]>tab[idEnd]){
      swap(tab,idDep,idEnd);
    }
  }
  return;
}

int aleapivot(int tab[],int  idDep,int idEnd){
  return idDep+(rand()%((idEnd-idDep)+1));
}

int reorgatab(int tab[],int pivot,int idDep,int idEnd){
  //Permet de repérer les lignes composées uniquement de la même valeur
  int noswap=-1;
  int i=idDep;
  int j=idEnd;
  while(i<j){

      //on evite de comparer les pivots à l'infini
      if(tab[i]==tab[pivot] && tab[j]==tab[pivot]){
        pivot=i;
        j--;
      }else if(tab[i]>=tab[pivot] && tab[j]<=tab[pivot]){
        pivot=swappivot(tab,i,j,pivot);
        noswap=1;
      }else  if(tab[i]<=tab[pivot] && tab[j]<=tab[pivot]){
        i++;
        noswap=1;
      }else if(tab[i]>=tab[pivot] && tab[j]>=tab[pivot]){
        j--;
        noswap=1;
      }else{
        i++;
        j--;
        noswap=1;
      }
  }
  if(noswap==-1){
    return -1;
  }else{
    return pivot;
  }
}

int swappivot(int tab[],int i,int j,int pivot){
  int tmp;
  if(i==pivot){
      pivot=j;
  }else if(j==pivot){
      pivot=i;
  }
  tmp=tab[i];
  tab[i]=tab[j];
  tab[j]=tmp;
  return pivot;
}

void swap(int tab[],int i,int j){
  int tmp;
  tmp=tab[i];
  tab[i]=tab[j];
  tab[j]=tmp;
}
