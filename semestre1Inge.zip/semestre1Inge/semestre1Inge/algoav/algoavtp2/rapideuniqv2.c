#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "rapideuniqv2.h"
#include "rapideuniqv1.h"
#include "selectionrapide.h"


//A partir d'un tableau de 3 cases on sélection la valeur de la dernière case du tableau qui servira de pivot
//on crée 2 sous-tableaux, les valeurs inferieures iront dans la partie gauche et celle égale ou supérieur iront à droite
//on met le pivot dans la première case du tableau droite.
//on fait cela jusqu'à n'avoir que des tableaux de taille inferieure ou égale à 2 puis à la remontée récursive
//on reconstitue le tableau principal en mettant bout à bout le tableau de gauche et de droite
//En plus de la version originale si la taille du tableau ou d'un sous-tableau est inférieur ou égal 280 valeurs, on utilise le tri par sélection rapide
void tri_rapideuniqv2(int tab[],int taille)
{
  int tmp;
    rapideuniqv2(tab,0,taille-1);
  return;
}


void rapideuniqv2(int tab[],int idDep, int idEnd){
  if((idEnd-idDep)<=280){
    tri_selection_rapide(&tab[idDep], (idEnd-idDep)+1);
    return;
  }
  if((idEnd-idDep)>1){
    int pivot;
    pivot=aleapivot(tab,idDep,idEnd);
    pivot=reorgatab(tab,pivot,idDep,idEnd);
    if(pivot!=-1){
      rapideuniqv2(tab,idDep,pivot-1);
      rapideuniqv2(tab,pivot,idEnd);
    }
  }else if((idEnd-idDep)==1){
    if(tab[idDep]>tab[idEnd]){
      swap(tab,idDep,idEnd);
    }
  }
  return;
}

//Voici l'algorithme de recherche de pivot median selon mes recherches sur internet
int pivotmedian(int tab[],int idDep,int idEnd){
  int idMid=(idDep+idEnd)/2;
  int idWin;
  if(tab[idDep]>=tab[idEnd]){
    idWin=idDep;
  }else{
    idWin=idEnd;
  }

  if(tab[idWin]>=tab[idMid]){
    return idWin;
  }else{
    return idMid;
  }
}
