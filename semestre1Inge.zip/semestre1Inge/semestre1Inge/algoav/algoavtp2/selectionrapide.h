#ifndef SELECTIONRAPIDE_H
#define SELECTIONRAPIDE_H

//prototype de fonction
void tri_selection_rapide(int tab[], int taille);

#endif
