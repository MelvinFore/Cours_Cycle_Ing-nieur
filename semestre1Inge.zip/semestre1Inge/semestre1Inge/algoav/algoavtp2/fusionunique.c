#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "fusionunique.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

void tri_fusionUnique(int tab[], int taille){
  div_tabUnique(tab,taille,0,taille-1);
}
void div_tabUnique(int tab[], int taille,int idDep, int idFin){
  if(idFin!=idDep){
    int idIntersec=(idFin+idDep)/2;
    div_tabUnique(tab,taille,idDep,idIntersec);
    div_tabUnique(tab,taille,idIntersec+1,idFin);
    fusionUnique(tab,taille,idDep,idIntersec+1,idFin);
  }
  return;
}

void fusionUnique(int tab[],int taille,int idDep,int idIntersec,int idFin){
  int tabtmp[(idFin-idDep)+1];
  int idDeptmp=idDep;
  int idIntersectmp=idIntersec;
  for(int i=0;i<=(idFin-idDep);i++){
    if(idDeptmp>=idIntersec){
      tabtmp[i]=tab[idIntersectmp];
      idIntersectmp++;
    }else if(idIntersectmp>=idFin+1){
      tabtmp[i]=tab[idDeptmp];
      idDeptmp++;
    }else{
      if(tab[idDeptmp]<tab[idIntersectmp]){
        tabtmp[i]=tab[idDeptmp];
        idDeptmp++;
      }else{
        tabtmp[i]=tab[idIntersectmp];
        idIntersectmp++;
      }
    }
  }
  for (int i=idDep,x=0;i<=idFin;i++,x++){
    tab[i]=tabtmp[x];
  }
}

/* Dans mon algorithme la complexité doit être O(2n*log(n)), on a log(n) car on divise le tableau en 2 sous tableau à l'aide des indices à chaque iteration
et 2n car on insère les valeurs une 1er fois dans un sous-tableau tampon et une deuxième fois de manière trié dans le tableau final
La plus grande différence avec le tri fusion classique est que celui-la est moins couteux en mémoire*/
