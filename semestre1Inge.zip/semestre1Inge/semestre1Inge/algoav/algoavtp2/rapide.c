#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "rapide.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

//A partir d'un tableau de 3 cases on selectionne la valeur de la dernière case du tableau qui servira de pivot
//on crée 2 sous-tableaux, les valeurs inferieures iront dans la partie gauche et celle égale ou supérieure iront à droite
//on met le pivot dans la première case du tableau droite.
//on fait cela jusqu'à n'avoir que des tableaux de taille inférieur ou égale à 2 puis à la remonte récursive
//on reconstitue le tableau principal en mettant bout à bout le tableau de gauche et de droite
void tri_rapide(int tab[],int taille)
{
  int tmp;
  int itab=0,idG=0,idD=0,pivot;
  int* partg;
  int* partd;
  //on gère le cas ou le tableau ne fait que deux cases
  if(taille==2){
    if(tab[0]>tab[1]){
      tmp=tab[0];
      tab[0]=tab[1];
      tab[1]=tmp;
    }
  }else if(taille>2){
    pivot=tab[taille-1];
    count_rapide(tab,taille,&idG,&idD,pivot);
    partg=(int*)malloc(sizeof(int)*idG);
    partd=(int*)malloc(sizeof(int)*idD);
    insert_rapide(tab,taille,partg,partd,pivot);
    tri_rapide(partg,idG);
    tri_rapide(partd,idD);
    for(int i=0;i<idG;i++){
      tab[itab]=partg[i];
      itab++;
    }
    for(int i=0;i<idD;i++){
      tab[itab]=partd[i];
      itab++;
    }
    free(partg);
    free(partd);
  }

  return;
}

//on calcule les tailles de chaque sous-tableau qui seront crée
void count_rapide(int tab[],int taille,int* gauche,int* droite,int pivot)
{
  for(int i=0;i<taille;i++){
    if(tab[i]<pivot){
      *gauche=*gauche+1;
    }else{
      *droite=*droite+1;
    }
  }
  return;
}

//on insère les valeurs dans chaque sous-tableau, selon si elles sont inferieures ou (superieur/égale) au pivot
void insert_rapide(int tab[],int taille, int tabg[], int tabd[], int pivot)
{
  int idG=0;
  int idD=1;
  for(int i=0; i<taille-1;i++){
    if(tab[i]<pivot){
      tabg[idG]=tab[i];
      idG++;
    }else{
      tabd[idD]=tab[i];
      idD++;
    }
  }
  tabd[0]=tab[taille-1];
  return;
}

/* je vais tenter de donner la complexité dans le pire des cas pour le tri rapide
je pense que pour les améliorations il ne sert à rien de recalculer la complexité car les opérations sont trop minimes pour être sougligné
( le pire des cas a lieu dès qu'on sélectionne un pivot, et que le tableau se divise en 2 tab contenant une valeur et l'autre contenant tout le reste)
dans ce cas on aura une complexité de O(n²) car cela revient pour chaque valeur à parcourir le tableau pour la placer.

Le seul cas ou cela n'arrive pas est celui ou on cherche une valeur médiane en guise de pivot, dans ce on sera en complexité O(2nlog(n)) 2 n pour l'insertion des valeurs dans les sous-tableaux et la remise en ordre dans le tableau principal.


En utilisant qu'un seul unique tableau sans tableau tampon on peut descende à (O(nlog(n))) */
