#ifndef FUSIONUNIQUE_H
#define FUSIONUNIQUE_H

//prototype de fonction
void tri_fusionUnique(int tab[], int taille);
void div_tabUnique(int tab[], int taille,int idDep, int idFin);
void fusionUnique(int tab[],int taille,int idDep,int idIntersec,int idFin);

#endif
