#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "selection.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

//Le principe de ce tri est de rechercher la plus petite valeur possible depuis notre valeur dans le tableau
//pour échanger leurs positions
void tri_selection(int tab[], int taille){
int tmp,tmpswap;
int idswap;
  //on sélectionne nos valeurs de base jusqu'à atteindre l'avant-dernière case du tableau
  for(int i=0;i<taille-1;i++){
    tmp=tab[i];
    idswap=i;
    //phase de recherche de la plus petite valeur
    for(int x=i;x<taille;x++){
      if(tab[x]<tmp){
        tmp=tab[x];
        idswap=x;
      }
    }
    //phase d'echange des valeurs
    tmpswap=tab[i];
    tab[i]=tmp;
    tab[idswap]=tmpswap;
  }
}

/* dans le pire des cas (par exemple la première valeur et la plus grande du tableau et la plus petite est l'avant-dernière,
dans ce cas il faudra à la case n-2 pour finaliser l'échange entre les deux dernières plus grandes valeurs, de toute façon au vu de l'implementation de la fonction la complexité sera toujours la
même sauf si on vérifie si le tableau est trié au départ, auquel cas on descend en O(n))
Donc comme on est de nouveau dans deux boucles imbriqué, on parcourt le tableau n² fois donc on a une complexité en O(n²)*/
