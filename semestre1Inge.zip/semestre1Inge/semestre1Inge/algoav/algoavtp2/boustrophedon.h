#ifndef BOUSTROPHEDON_H
#define BOUSTROPHEDON_H

//prototype de fonction
void tri_boustrophedon(int tab[],int taille);

#endif
