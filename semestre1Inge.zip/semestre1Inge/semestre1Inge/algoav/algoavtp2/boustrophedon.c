#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "boustrophedon.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

//Même principe que le tri à Bulle sauf qu'au moment où on a parcouru le tableau dans un sens
//on le reparcourt dans le sens inverse pour continuer le tri
//du début vers la fin on emmène la plus grande valeur et dans l'autre sens c'est la plus petite valeur
void tri_boustrophedon(int tab[],int taille){
  bool swap=true;
  bool endswap;
  int tmp,decId,demitaille;
  decId=0;

  if(taille%2==0){
    demitaille=taille/2;
  }else{
    demitaille=(taille/2)+1;
  }

  while(decId!=demitaille){
    endswap=false;
    if(swap==true){
      for(int i=0+decId;i<(taille-1)-decId;i++){
        if(tab[i]>tab[i+1]){
          endswap=true;
          tmp=tab[i];
          tab[i]=tab[i+1];
          tab[i+1]=tmp;
        }
      }
    swap=false;
    }else{
      for(int i=(taille-1)-decId-1;i>0+decId;i--){
        if(tab[i]<tab[i-1]){
          endswap=true;
          tmp=tab[i];
          tab[i]=tab[i-1];
          tab[i-1]=tmp;
        }
      }
    decId++;
    swap=true;
    }
  if(endswap==false){
      break;
  }
  }
}

/* dans le pire des cas (toujours triés dans l'ordre décroissant)
La complexité de l'algo sera d'ordre O(n²) car on va parcourir le tableau n*(n-i) avec
i augmentant a chaque iteration, il n'y a pas de différence notable avec le tri à bulle classique
D'apres mes recherches internet ce tri devient intéressant dans des tableaux avec les trois quarts déjà triés, ceci est un cas très spécifique*/
