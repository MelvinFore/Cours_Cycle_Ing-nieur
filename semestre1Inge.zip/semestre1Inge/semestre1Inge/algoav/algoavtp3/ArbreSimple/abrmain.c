#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbre.h"
#include "fileabr.h"
#include "abrnodestack.h"
#include "parcours.h"
#include "rechabr.h"

int main(void){
	int continuer=1;
	Arbre* abr=creerNouvelarbre();
	if(abr->racine==NULL){
		printf("l'abre est vide\n");
	}
	while(continuer==1){
		ajoutelemArbre(abr);
		printf("tapez 1 pour continuer: ");
		scanf("%d",&continuer);
		printf("\n");
	}
	Sup_elemSuper(abr,5);

	printf("Debut parcours\n");
	Depth_first(abr->racine,NULL);
	//printf("Debut parcours\n");
	//Breadth_First_Search(abr->racine);
	printf("\n");


	printf("la hauteur de l'arbre est de %d\n",Arbrehauteur(abr->racine,1));
	abr->racine=del(abr->racine);
	if(abr->racine==NULL){
		printf("l'abre est vide\n");
	}
	free(abr);
}
