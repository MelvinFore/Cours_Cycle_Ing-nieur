#ifndef RECHABR_H
#define RECHABR_H


//prototype de fonction
void Depth_elem(Noeud *racine,int valsup,int profondeur);
int Sup_elem(Noeud *racine,Noeud* pere,int dirsup,int valsup);
void Sup_elemSuper(Arbre *abr,int valsup);
#endif
