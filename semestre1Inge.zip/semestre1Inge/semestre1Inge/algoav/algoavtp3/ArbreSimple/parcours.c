#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbre.h"
#include "fileabr.h"
#include "abrnodestack.h"
#include "parcours.h"

int Arbrehauteur(Noeud* racine,int hauteur){
	Noeud* courant=racine;
	int valFdroit=0;
	int valFgauche=0;
	if(courant==NULL){
		return 0;
	}

	if(courant->filsG!=NULL){
		valFgauche=hauteur+1;
		valFgauche=Arbrehauteur(courant->filsG,valFgauche);
	}
	if(courant->filsD!=NULL){
		valFdroit=hauteur+1;
		valFdroit=Arbrehauteur(courant->filsD,valFdroit);
	}

	if(valFgauche==0 && valFdroit==0){
		return hauteur;
	}else if(valFgauche>=valFdroit){
		return valFgauche;
	}else{
		return valFdroit;
	}
}

void Depth_first(Noeud *racine,Noeud* valpred){
	Noeud* courant=racine;
	if(courant==NULL){
		return;
	}
	if(valpred==NULL){
		printf("(%d)\n",courant->donnee);
	}else{
		printf("(%d)->(%d)\n",valpred->donnee,courant->donnee);
	}

	if(courant->filsG!=NULL){
		Depth_first(courant->filsG,courant);
	}
	if(courant->filsD!=NULL){
		Depth_first(courant->filsD,courant);
	}
	return;
}

void Breadth_First_Search(Noeud *racine){
	Noeud* courant=racine;
	Noeud* Fg;
	Noeud* Fd;
	File* filenode=creerNouvelleFile();
	if(courant==NULL){
		return;
	}
	enfilement(filenode,courant);
	courant=NULL;
	while(filenode->tete!=NULL){

		courant=defilement(filenode);
		printf("%d\n",courant->donnee);
		if(courant->filsG!=NULL){
			enfilement(filenode,courant->filsG);
		}
		if(courant->filsD!=NULL){
			enfilement(filenode,courant->filsD);
		}
	}
	free(filenode);
	return;
}

void Depth_firstIterative(Noeud* racine){
	if(racine==NULL){
		return;
	}
	Noeud* courant=racine;
	StackN* elemstk=creerNouvellePileN();
	empilerN(elemstk,courant);
	while(elemstk->tete!=NULL){
		courant=depilerN(elemstk);
		printf("%d\n",courant->donnee);
		if(courant->filsD!=NULL){
			empilerN(elemstk,courant->filsD);
		}
		if(courant->filsG!=NULL){
			empilerN(elemstk,courant->filsG);
		}
	}
}
