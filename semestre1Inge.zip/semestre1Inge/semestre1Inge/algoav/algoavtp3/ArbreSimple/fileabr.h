#ifndef FILEABR_H
#define FILEABR_H

//prototype de fonction
// Définition de la structure d'un element de la file
typedef struct Element
{
	Noeud* donnee;
	struct Element* suivant;
} Element;

// Définition de la structure de la file
typedef struct File
{
	Element* tete; // Pointeur vers le premier élément de la liste
} File;

File* creerNouvelleFile();
Element* creerNouvelElement(Noeud* valeur);
void est_videfile(File* file);
void enfilement(File* file,Noeud* valeur);
Noeud* defilement(File* file);

#endif
