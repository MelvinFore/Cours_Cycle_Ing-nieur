#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"arbrebin.h"
#include"parcoursbin.h"
#include"rechabrbin.h"


int main(void){
	int continuer=1;
	Arbrebin* abr=creerNouvelarbrebin();
	while(continuer==1){
		AjoutElemArbrebin(abr);
		printf("tapez 1 pour continuer\n");
		scanf("%d",&continuer);
	}
	if(est_vide(abr)){
		printf("l'abre est vide\n");
	}
	Depth_first(abr->racine,NULL);
	printf("apres supresion\n\n");
	sup_elem(abr->racine,NULL,12);
	Depth_first(abr->racine,NULL);
	printf("la hauteur est de %d\n",Arbrehauteur(abr->racine,1));
	del(abr->racine);
	free(abr);
}
