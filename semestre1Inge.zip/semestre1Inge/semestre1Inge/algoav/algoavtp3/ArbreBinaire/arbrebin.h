#ifndef ARBREBIN_H
#define ARBREBIN_H

// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure de l'arbre
typedef struct Noeud
{
	int donnee;
	struct Noeud* filsG;
	struct Noeud* filsD;
} Noeud;

// Définition de la structure de l'arbre
typedef struct Arbrebin
{
	Noeud* racine; // Pointeur vers le premier élément de la liste
} Arbrebin;

//prototype de fonction
Arbrebin* creerNouvelarbrebin();
Noeud* creerNoeud(int valeur);
bool est_vide(Arbrebin* abr);
void AjoutElemArbrebin(Arbrebin* abr);
Noeud* del(Noeud *racine);

#endif
