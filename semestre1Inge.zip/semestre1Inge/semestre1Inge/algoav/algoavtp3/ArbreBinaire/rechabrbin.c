#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"arbrebin.h"
#include"rechabrbin.h"

void sup_elem(Noeud* racine,Noeud* Npred,int valsup){
	Noeud* courant=racine;
	if(courant->donnee>valsup){
		if(courant->filsG!=NULL){
			sup_elem(courant->filsG,courant,valsup);
		}else{
			//dans ce cas la valeur n'existe pas
			return;
		}
	}else if(courant->donnee<valsup){
		if(courant->filsD!=NULL){
			sup_elem(courant->filsD,courant,valsup);
		}else{
			//dans ce cas la valeur n'existe pas
			return;
		}
	}else{
		//cas ou on est dans le noeud contenant la valeur
		if(courant->filsG==NULL && courant->filsD==NULL){
			free(courant);
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=NULL;
				}else if(Npred->donnee<valsup){
					Npred->filsD=NULL;
				}
			}
		}else if(courant->filsG!=NULL && courant->filsD==NULL){
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=courant->filsG;
				}else if(Npred->donnee<valsup){
					Npred->filsD=courant->filsG;
				}
			}else{
				racine=courant->filsG;
			}
			free(courant);
		}else if(courant->filsG==NULL && courant->filsD!=NULL){
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=courant->filsD;
				}else if(Npred->donnee<valsup){
					Npred->filsD=courant->filsD;
				}
			}else{
				racine=courant->filsD;
			}
			free(courant);
		}else{
			Noeud* changeNode=courant;
			int dirsup=0;
			Npred=courant;
			courant=courant->filsD;
			//On recherche la valeur la plus petite du sous-arbre droit
			while(courant->filsG!=NULL){
				dirsup=1;
				Npred=courant;
				courant=courant->filsG;
			}
			if(dirsup==0){
				Npred->filsD=courant->filsD;
			}else{
				Npred->filsG=courant->filsD;
			}
		changeNode->donnee=courant->donnee;
		free(courant);
		}
		return;
	}
	return;
}
