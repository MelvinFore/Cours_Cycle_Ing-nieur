#ifndef PARCOURSBIN_H
#define PARCOURSBIN_H


//prototype de fonction
int Arbrehauteur(Noeud* racine,int hauteur);
void Depth_first(Noeud *racine,Noeud* valpred);
#endif
