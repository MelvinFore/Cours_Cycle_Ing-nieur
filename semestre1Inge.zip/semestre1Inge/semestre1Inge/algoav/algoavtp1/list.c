#include<stdio.h>
#include<string.h>
#include<stdlib.h>


// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure d'une cellule de la liste chaînée
typedef struct Cellule
{
  int donnee;
  struct Cellule* suivante;
} Cellule;

// Définition de la structure de la liste chaînée
typedef struct Liste
{
  Cellule* tete; // Pointeur vers le premier élément de la liste
} Liste;

Cellule* creerNouvelleCellule(int valeur);
Liste* creerNouvelleListe();
void est_vide(Liste* liste);
void ajouterEnTete(Liste* liste, int valeur);
void ajouterEnQueue(Liste* liste, int valeur);
void ajouterEnPosition(Liste* liste,int position, int valeur);
void supprimerElement(Liste* liste, int valeur);
void rechlistval(Liste* liste,int valeur);
void rechlistpos(Liste* liste,int position);
int countlist(Liste* liste);
void parclist(Liste* liste);
void freelist(Liste* liste);


int main(void){
  Liste* nwliste=creerNouvelleListe();
  ajouterEnQueue(nwliste,99);
  ajouterEnTete(nwliste,7);
  est_vide(nwliste);
  ajouterEnTete(nwliste,25);
  ajouterEnTete(nwliste,12);
  ajouterEnTete(nwliste,56);
  ajouterEnTete(nwliste,7);
  ajouterEnQueue(nwliste,277);
  ajouterEnQueue(nwliste,7);
  parclist(nwliste);
  freelist(nwliste);
  est_vide(nwliste);
  free(nwliste);
}

// Fonction pour créer une nouvelle cellule avec une valeur donnée
Cellule* creerNouvelleCellule(int valeur)
{
  Cellule* nouvelleCellule = (Cellule*)malloc(sizeof(Cellule));
  if (nouvelleCellule == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la cellule.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelleCellule->donnee = valeur;
  nouvelleCellule->suivante = NULL;
  return nouvelleCellule;
}

// Fonction pour créer une nouvelle liste vide
Liste* creerNouvelleListe()
{
  Liste* nouvelleListe = (Liste*)malloc(sizeof(Liste));
  if (nouvelleListe == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la liste.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelleListe->tete = NULL;
  return nouvelleListe;
}

//Fonction qui indique si la liste est vide
void est_vide(Liste* liste){
  if(liste->tete==NULL){
    printf("La liste est vide\n");
  }else{
    printf("La liste est non vide\n");
  }
  return;
}

// Fonction pour ajouter une cellule en tête de la liste chaînée
void ajouterEnTete(Liste* liste, int valeur)
{
  Cellule* nouvelleCellule = creerNouvelleCellule(valeur);
  nouvelleCellule->suivante = liste->tete;
  liste->tete = nouvelleCellule;
}

//Fonction pour ajouter une cellule en queue
void ajouterEnQueue(Liste* liste, int valeur)
{
	if(liste->tete==NULL){
		liste->tete=creerNouvelleCellule(valeur);
		return;
	}
	Cellule* courante=liste->tete;
	while(courante->suivante!=NULL){
		courante=courante->suivante;
	}
	courante->suivante=creerNouvelleCellule(valeur);
	return;
}

//Fonction qui ajoute au sein d'une liste une nouvelle cellule à une position données, la cellule a la position données est decalée vers la droite et toute les autres cellules la suivant
void ajouterEnPosition(Liste* liste, int position, int valeur)
{
  int cpt=1;
  int limite=countlist(liste);
  Cellule* courante=liste->tete;
  Cellule* pred=NULL;
  if(position<=0 || position>limite || liste->tete==NULL){
    printf("la position selectionnée ne se trouve pas dans la liste\n");
  }else if(position==1){
    ajouterEnTete(liste,valeur);
  }else {
    while(cpt<position-1){
      cpt++;
      courante=courante->suivante;
    }
    pred=courante;
    courante=courante->suivante;
    pred->suivante=creerNouvelleCellule(valeur);
    pred=pred->suivante;
    pred->suivante=courante;
  }
  return;
}

// Fonction pour supprimer une cellule avec une valeur donnée de la liste chaînée
void supprimerElement(Liste* liste, int valeur) {
  Cellule* courante = liste->tete;
  Cellule* precedente = NULL;
  //on traite le cas ou la cellule a supprimer ce trouve au debut de la liste
  if (courante != NULL && courante->donnee == valeur) {
      liste->tete = courante->suivante;
      free(courante);
      return;
  }
  //On parcourt la liste jusqu'a ce qu'on trouve la valeur ou que la liste soit totalement parcourut
  while (courante != NULL && courante->donnee != valeur) {
    precedente = courante;
    courante = courante->suivante;
  }
  //si la cellule courante est null c'est que la valeur a supprimer n'est pas dans la liste
  if (courante == NULL) {
    printf("La valeur %d n'a pas été trouvée dans la liste.\n", valeur);
    return;
  }

  precedente->suivante = courante->suivante;
  free(courante);
}

//Fonction dans laquelle on indique une valeur et une liste, elle nous retournera toutes les positions de cette valeur au sein de la liste
void rechlistval(Liste* liste,int valeur)
{
	bool trouve=false;
	int pos=1;
	if(liste->tete==NULL){
		printf("il n'y a pas de valeur dans la liste\n");
		return;
	}
	printf("maintenant on affichera les positions de la valeur %d  dans la liste en allant de 1 a la fin de la liste\n",valeur);
	Cellule* courante=liste->tete;
	while(courante!=NULL){
		if(courante->donnee==valeur){
			printf("%d ->",pos);
			trouve=true;
		}
		pos++;
		courante=courante->suivante;
	}
	printf("\n");
	if(trouve==false){
		printf("aucune occurence de la valeur dans la liste\n");
	}
	return;
}

//Fonction qui retourne une valeur contenu à une position donné si elle existe
void rechlistpos(Liste* liste, int position)
{
	int limite=countlist(liste);
	if(position>limite||position<=0||liste->tete==NULL){
		printf("la position n'est pas contenu dans la liste\n");
		return;
	}

	int cpt=1;
	Cellule* courante=liste->tete;
	while(cpt<position){
		cpt++;
		courante=courante->suivante;
	}

	printf("A la position %d on retrouve la valeur %d\n",position,courante->donnee);
	return;
}

//Fonction qui compte toute les valeurs d'une liste
int countlist(Liste* liste)
{
	if(liste->tete==NULL){
		return 0;
	}
	Cellule* courante=liste->tete;
	int cpt=0;
	while(courante!=NULL){
		cpt++;
		courante=courante->suivante;
	}
	return cpt;
}

//Fonction qui affiche toute les valeurs presente au sein d'une liste
void parclist(Liste* liste){
  Cellule* courante=liste->tete;
  while(courante!=NULL){
    printf("%d-",courante->donnee);
    courante=courante->suivante;
  }
  printf("\n");
}

//Fonction qui libere tout l'espace alloué pour les cellules d'une liste
void freelist(Liste* liste){
  Cellule* courante=liste->tete;
  while(liste->tete!=NULL){
    courante=courante->suivante;
    free(liste->tete);
    liste->tete=courante;
  }
}
