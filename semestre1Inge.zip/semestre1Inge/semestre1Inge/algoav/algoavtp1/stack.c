#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Element{
  int donnee;
  struct Element* suivant;
} Element;

typedef struct Stack{
Element* tete;
}   Stack;

Element* creerNouvelElement(int valeur);
Stack* creerNouvellePile();
void est_vide(Stack* stk);
void empiler(Stack* stk,int valeur);
int depiler(Stack* stk);
void PileSize(Stack* stk);
void AffPile(Stack* stk);
void AffToP(Stack* stk);
Stack* cpyStack(Stack* stk);
void AjoutRecStack(Stack* stk, Stack* stkcpy);
Stack* concatStack(Stack* stk1, Stack* stk2);
void FreePile(Stack* stk);

int main(void){
Stack* nwp=creerNouvellePile();
Stack* cpytest;
Stack* testconcat;
est_vide(nwp);
empiler(nwp,7);
empiler(nwp,-895);
AffToP(nwp);
empiler(nwp,9);
empiler(nwp,17);
cpytest=cpyStack(nwp);
AffPile(nwp);
AffPile(cpytest);
testconcat=concatStack(nwp,cpytest);
AffPile(testconcat);
FreePile(nwp);
FreePile(cpytest);
est_vide(nwp);
free(nwp);
free(cpytest);
}

// Fonction pour créer une nouvelle cellule avec une valeur donnée
Element* creerNouvelElement(int valeur)
{
  Element* nouvelElement = (Element*)malloc(sizeof(Element));
  if (nouvelElement == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la element.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelElement->donnee = valeur;
  nouvelElement->suivant = NULL;
  return nouvelElement;
}

// Fonction pour créer une nouvelle liste videint valeur
Stack* creerNouvellePile()
{
  Stack* nouvellePile = (Stack*)malloc(sizeof(Stack));
  if (nouvellePile == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la liste.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvellePile->tete = NULL;
  return nouvellePile;
}

//Fonction qui verifie si la pile est vide
void est_vide(Stack* stk){
  if(stk->tete==NULL){
    printf("la pile est vide\n");
  }else{
    printf("la pile est non vide\n");
  }
  return;
}

//Fonction qui permet d'ajouter un nouvel element à la liste
void empiler(Stack* stk,int valeur){
  Element* NouvelElement=creerNouvelElement(valeur);
  NouvelElement->suivant=stk->tete;
  stk->tete=NouvelElement;
  return;
}

//Fonction qui permet d'enlever l'element du dessus de la pile
int depiler(Stack* stk){
  int valeurElem;
  if(stk->tete==NULL){
    printf("Cela ne sert pas de depiler une pile vide\n");
    return -1;
  }

  Element* Courant=stk->tete;
  stk->tete=Courant->suivant;
  valeurElem=Courant->donnee;
  free(Courant);
  return valeurElem;
}

//Fonction qui depile notre Pile dans une autre tampon pour compter le nombre d'éléments
//Puis on depile le tampon dans notre Pile d'origine pour recuperer notre structure initial
void PileSize(Stack* stk)
{
  if(stk->tete==NULL)
  {
    printf("la taille de la pile est 0\n");
    return;
  }
  int valrecup,cpt=0;
  Stack* tmp=creerNouvellePile();
  while(stk->tete!=NULL){
    valrecup=depiler(stk);
    empiler(tmp,valrecup);
    cpt++;
  }
  while(tmp->tete!=NULL){
    valrecup=depiler(tmp);
    empiler(stk,valrecup);
  }
  printf("il y a %d element dans notre pile\n",cpt);
  free(tmp);
  return;
}

//Idem PileSize sauf que la on affiche les valeurs
void AffPile(Stack* stk)
{
  if(stk->tete==NULL)
  {
    return;
  }
  int valrecup;
  Stack* tmp=creerNouvellePile();
  printf("\n ////////AFFICHAGE DE LA PILE/////// \n");
  while(stk->tete!=NULL){
    valrecup=depiler(stk);
    empiler(tmp,valrecup);
    printf("%d\n|\n",valrecup);
  }
  printf("\n ////////FIN AFFICHAGE/////// \n");
  while(tmp->tete!=NULL){
    valrecup=depiler(tmp);
    empiler(stk,valrecup);
  }
  free(tmp);
  return;
}

//On affiche la valeur de l'element au dessus de la liste
void AffToP(Stack* stk) {
  if(stk->tete==NULL){
    return;
  }
  Element* Aff=stk->tete;
  printf("%d\n",Aff->donnee);
  return;
}

Stack* cpyStack(Stack* stk){
  Stack* stkcpy=creerNouvellePile();
  if(stk->tete!=NULL){
    AjoutRecStack(stk,stkcpy);
  }
  return stkcpy;
}

void AjoutRecStack(Stack* stk, Stack* stkcpy){
  int valcpy;
  if(stk->tete!=NULL){
    valcpy=depiler(stk);
    AjoutRecStack(stk,stkcpy);
    empiler(stk,valcpy);
    empiler(stkcpy,valcpy);
  }
  return;
}

Stack* concatStack(Stack* stk1, Stack* stk2){
    Stack* stkconcat=creerNouvellePile();
    AjoutRecStack(stk1,stkconcat);
    AjoutRecStack(stk2,stkconcat);
    return stkconcat;
}

//On depile la pile entiere si elle est non vide
void FreePile(Stack* stk)
{
  if(stk->tete==NULL)
  {
    return;
  }
  while(stk->tete!=NULL){
    depiler(stk);
  }
  return;
}
