#include<stdio.h>
#include<string.h>

int euclidPGCD(int valeurd,int mod, int *u, int *v){
	if(valeurd==0){
		*u=0;
		*v=0;
	return mod;
	}
	int urec,vrec;
	int pgcd=euclidPGCD(mod%valeurd,valeurd,&urec,&vrec);

	*u=vrec-(mod/valeurd)*urec;
	*v=urec;
	return pgcd;
}

int main(void)
{
	int valeur=14;
	int modulo=101;
	int u,v;

	printf("PGCD=%d\n",euclidPGCD(valeur,modulo,&u,&v));
	if(u<0){
		u=modulo+u;
	}
}
