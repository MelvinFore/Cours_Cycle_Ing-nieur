#include<stdarg.h>
#include<stdio.h>

// Exemple de fonction variadique
int foo(int v, ...) {
    int x = 0;
    int valeur;
    // --- déclaration de la liste de paramètres indéfinie
    va_list my_list_of_parameters;
    // ---

    // --- pointage au début de la liste indéfinie sur un
    // --- paramètre connu
    va_start(my_list_of_parameters,v);
    // ---
    //On recupere donc en premier la valeur de v qui compte maintenant comme une valeur à additionner
    valeur=v;
    //Maintenant on ne compte plus le nombre indique, mais on attend que v soit egale à 0, ce qui nous permet d'avoir un
    //nombre indefini de variables
    while(valeur!=0) {

        // --- récupération du prochain paramètre
        x += valeur;
        valeur=va_arg(my_list_of_parameters, int);

    }

    // --- terminaison processus de lecture de la liste indéfinie
    va_end(my_list_of_parameters);
    // ---

    return(x);
}

int main() {
    printf("out: %d\n", foo(3, 4, 0, 6, 7 , 7 ,0));
    return(0);
}
