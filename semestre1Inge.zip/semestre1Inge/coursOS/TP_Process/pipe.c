#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(){
    int fdS;
    int cpy0;
    int fd[2];
    char str[200];
    char c;
    while(1){
      //on cree le pipe
      pipe(fd);
      printf("\nveuiller indiquer un nom de fichier\n");
      scanf("%s",str);
      //On copie est ferme stdin
      cpy0=dup(0);
      close(0);
      //On cree le descripteur qui remplacera stdin par le contenu d'un fichier
      fdS=open(str,O_RDONLY);
      if(fdS==-1){
        printf("Ce fichier n'existe pas");
        close(fdS);
        dup(cpy0);
        close(cpy0);
        continue;
      }
      //On duplique notre processus
      if(fork()){
        close(fd[0]);
        //Le pere lit et envoie le contenu du fichier au fils
        while(read(0,&c,sizeof(char))){
          write(fd[1],&c,sizeof(char));
        }
        close(fd[1]);
      }else{
          close(fd[1]);
          close(0);
          dup(fd[0]);
          //On lit les informations envoye par le pere dans le pipe
          while (read(0,&c,sizeof(char))){
            //TRANSFORMATION MAJUSCULES
              /* si les caractères sont en minuscules, convertissez-les
              en majuscules en soustrayant 32 de leur valeur ASCII. */
              if(c >= 'a' && c <= 'z') {
                c = c -32;
              }
            //ON AFFICHE
            printf("%c",c);
          }
          close(fd[0]);
          break;
      }
      //Le pere attend la fin du fils
      wait(NULL);
      close(fdS);
      dup(cpy0);
      close(cpy0);
    }
}
