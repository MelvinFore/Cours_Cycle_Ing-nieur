#include <stdio.h>
#include <stdarg.h>

int somme(int nombre, ...) {
va_list args;
va_start(args, nombre);
int somme = 0;
for (int i = 0; i < nombre; ++i) {
somme += va_arg(args, int);
}
va_end(args);
return somme;
}

int main() {
  // Utilisation de la fonction variadique
  int resultat = somme(3, 1, 2, 3);
  // Affichage du résultat
  printf("Somme : %d\n", resultat);
  return 0;
}
