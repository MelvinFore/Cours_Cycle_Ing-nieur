#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>

/*D'apres mes tests moins il y a de thread meilleur sera le resultat, je pense que cela est du à une mauvaise parallelisation*/

typedef struct
{
   pthread_mutex_t* mx1;
   pthread_barrier_t* endmult;
   int* idparc;
   int tailleV;
   int *vectA;
   int *vectB;
   int *vectResult;
}valvect;

void *multvect(void *p) {
  int idmult;
  valvect* mstruct=(valvect*)p;
  while(*(mstruct->idparc)<(mstruct->tailleV)) {
    pthread_mutex_lock(mstruct->mx1);
    if(*(mstruct->idparc)<(mstruct->tailleV)) {
      idmult=*(mstruct->idparc);
      *(mstruct->idparc)=*(mstruct->idparc)+1;
      pthread_mutex_unlock(mstruct->mx1);
    }else{
      pthread_mutex_unlock(mstruct->mx1);
      break;
    }
    mstruct->vectResult[idmult]=mstruct->vectA[idmult]*mstruct->vectB[idmult];
  }
  pthread_barrier_wait(mstruct->endmult);
	return(NULL);
}

void *addvect(void *p) {
  int sum=0;
  valvect* mstruct=(valvect*)p;
  pthread_barrier_wait(mstruct->endmult);
  for(int i=0;i<mstruct->tailleV;i++)
    sum=sum+mstruct->vectResult[i];
  printf("la somme est de %d\n",sum);
	return(NULL);
}


int main() {
  int tvect;
  int nbthread;
  printf("Entrez la taille du vecteur a traiter:");
  scanf("%d",&tvect);
  printf("Entrez nombre de thread pour la phase multiplication:");
  scanf("%d",&nbthread);
  printf("\n");
  if(tvect>=1 && nbthread>=1){
    int initidparc=0;
    nbthread++;
    int *vectAinit=(int*) malloc(tvect*sizeof(int));
    for(int i=0;i<tvect;i++){
      vectAinit[i]=i;
    }
    int *vectBinit=(int*) malloc(tvect*sizeof(int));
    for(int i=0;i<tvect;i++){
      vectBinit[i]=i;
    }
    int *vectRinit=(int*) malloc(tvect*sizeof(int));
    pthread_mutex_t mx1;
    pthread_mutex_init(&mx1, NULL);
    valvect mystruct[nbthread];
    pthread_t t[nbthread];
    pthread_barrier_t barrier;
    pthread_barrier_init(&barrier, NULL, nbthread);
    for(int i=1; i<nbthread;i++){
      mystruct[i].idparc=&initidparc;
      mystruct[i].mx1=&mx1;
      mystruct[i].endmult=&barrier;
      mystruct[i].tailleV=tvect;
      mystruct[i].vectA=vectAinit;
      mystruct[i].vectB=vectBinit;
      mystruct[i].vectResult=vectRinit;
      pthread_create(&t[i], NULL, multvect,(void *) &mystruct[i]);
    }
    mystruct[0].idparc=&initidparc;
    mystruct[0].mx1=&mx1;
    mystruct[0].endmult=&barrier;
    mystruct[0].tailleV=tvect;
    mystruct[0].vectA=vectAinit;
    mystruct[0].vectB=vectBinit;
    mystruct[0].vectResult=vectRinit;
    pthread_create(&t[0], NULL, addvect,(void *) &mystruct[0]);
    // int pthread_join(pthread_t thread, void **retval);
    for(int i=0; i<nbthread;i++)
      pthread_join(t[i], NULL);
    free(vectAinit);
    free(vectBinit);  
  }
	return(EXIT_SUCCESS);
}
