#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
  char c;
  while(read(0,&c,sizeof(char))){
    write(1,&c,sizeof(char));
  }
}
