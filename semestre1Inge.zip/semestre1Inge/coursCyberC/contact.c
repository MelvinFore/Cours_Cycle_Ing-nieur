/*on doit creer un prog de gestion de contact
contenant une structure
-nom
-prenom
-numtel

les contact seront range dans un tableau dynamique
une commande qui liste tous les contact
et une pour en supprimer un
*/
#include<string.h>
#include <stdlib.h>
#include <stdio.h>

struct contact{
  char nom[50];
  char prenom[50];
  char num[10]
};
typedef struct contact cnt;

cnt ajouter();
int supprimer(cnt *tab,int taille);
void listing(cnt *tab,int taille);

int main(void){
  int bool=0;
  int option=0;
  int taille=1;
  cnt* list_contact;
  cnt defaut={"vide","vide","-1"};
  list_contact=(cnt *)malloc(sizeof(cnt)*taille);
  list_contact[0]=defaut;

  while(option!=-1){
    printf("Voulez vous:\n 1:ajouter un contact\n 2:supprimer un contact\n 3:voir la liste de vos contact\n");
    scanf("%d",&option);
    if(option==1){
        if(taille==1){
          list_contact[0]=ajouter();
          taille=taille+1;
        }else{
          list_contact=(cnt *)realloc(list_contact,sizeof(cnt)*taille);
          list_contact[taille-1]=ajouter();
          taille=taille+1;
      }
    }else if(option==2){
      taille=supprimer(list_contact,taille);
    }else if(option==3){
      listing(list_contact,taille);
    }
    bool=0;
  }

}

cnt ajouter(){
  cnt new;
  printf("veuillez indiquer un nom \n");
  scanf("%s",new.nom);
  printf("veuillez indiquer un prenom \n");
  scanf("%s",new.prenom);
  printf("veuillez indiquer un numero de telephone\n");
  scanf("%s",new.num);

  printf("%s-%s-%s\n",new.nom,new.prenom,new.num);

  return new;

}

int supprimer(cnt *tab,int taille){
  int elem;
  listing(tab,taille);
  printf("indiquez un elem a supprimer: ");
  scanf("%d",&elem);
  printf("\n");
  if(elem==taille-1){
    taille=taille-1;
    tab=(cnt *)realloc(tab,sizeof(cnt)*taille-1);
  }else if(elem>=0 && elem<taille-1){
    tab[elem]=tab[taille-2];
    taille=taille-1;
    tab=(cnt *)realloc(tab,sizeof(cnt)*taille-1);
  }
  return taille;
}

void listing(cnt *tab,int taille){
  for(int i=0;i<taille-1;i++){
    printf("%d: %s-%s-%s\n",i,tab[i].nom,tab[i].prenom,tab[i].num);
  }
}
