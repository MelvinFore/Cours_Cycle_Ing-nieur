#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"arbrebin.h"

// Fonction pour créer un nouvel arbre
Arbrebin* creerNouvelarbrebin()
{
	Arbrebin* nouvelarbre = (Arbrebin*)malloc(sizeof(Arbrebin));
	if (nouvelarbre == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour l'arbre.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvelarbre->racine = NULL;
	return nouvelarbre;
}

// Fonction pour créer un nouveaunoeud
Noeud* creerNoeud(int valeur)
{
	Noeud* nouveauNoeud = (Noeud*)malloc(sizeof(Noeud));
	if (nouveauNoeud == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour le noeud.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouveauNoeud->donnee = valeur;
	nouveauNoeud->filsG = NULL;
	nouveauNoeud->filsD = NULL;
	return nouveauNoeud;
}

bool est_vide(Arbrebin* abr)
{
	if(abr->racine==NULL){
		return true;
	}else{
		return false;
	}
}

//On supprime tout l'arbre en partant des feuilles
Noeud* del(Noeud *racine){
	Noeud* courant=racine;
	if(courant==NULL){
		return NULL;
	}

	if(courant->filsG!=NULL){
		del(courant->filsG);
	}
	if(courant->filsD!=NULL){
		del(courant->filsD);
	}
	free(courant);
	return NULL;
}

//Fonction ajout d'elment
//Gauche plus petit
//Droite plus grand
void AjoutElemArbrebin(Arbrebin* abr){
	Noeud* courant=abr->racine;
	//On cree la valeur à ajouter dans l'arbre
	int nwval;
	printf("veuillez indiquer une valeur: ");
	scanf("%d",&nwval);

	if(est_vide(abr)==true){
		abr->racine=creerNoeud(nwval);
		return;
	}

	while(courant!=NULL){
		if(courant->donnee>nwval){
			if(courant->filsG==NULL){
				courant->filsG=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsG;
			}

		}else if(courant->donnee<nwval){
			if(courant->filsD==NULL){
				courant->filsD=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsD;
			}
		}else{
			return;
		}
	}
}
