#ifndef RECHABRBIN_H
#define RECHABRBIN_H


//prototype de fonction
void sup_elem(Noeud* racine,Noeud* Npred,int valsup);
#endif
