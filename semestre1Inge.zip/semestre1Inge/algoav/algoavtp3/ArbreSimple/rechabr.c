#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbre.h"
#include "rechabr.h"

void Depth_elem(Noeud *racine,int valsup,int profondeur){
	Noeud* courant=racine;
	if(courant==NULL){
		return;
	}
	if(valsup==courant->donnee){
		printf("la valeur %d se situe a la profondeur%d\n",courant->donnee,profondeur);
	}

	if(courant->filsG!=NULL){
		Depth_elem(courant->filsG,valsup,1+profondeur);
	}
	if(courant->filsD!=NULL){
		Depth_elem(courant->filsD,valsup,1+profondeur);
	}
	return;
}

void Sup_elemSuper(Arbre* abr,int valsup){
	if(Sup_elem(abr->racine,NULL,0,5)){
		abr->racine=NULL;
	}
}

//D abord faire une fonction pour verifier la racine
//On supprime toutes les occurences d'un element dans l'Arbre
//On recherche la feuille la plus a droite de l'arbre pour echanger sa valeur avec notre noeud actuel
int Sup_elem(Noeud *racine,Noeud* pere,int dirsup,int valsup){
	Noeud * courant=racine;
	Noeud * pred=pere;
	Noeud * val=racine;
	int dirold;
	while(courant->donnee==valsup){
		dirold=dirsup;
		while(courant->filsG!=NULL || courant->filsD!=NULL){
			pred=courant;
			if(courant->filsD!=NULL){
				dirsup=1;
				courant=courant->filsD;
			}else{
				dirsup=2;
				courant=courant->filsG;
			}
		}

		if(dirsup==1){
			val->donnee=courant->donnee;
			pred->filsD=NULL;
		}else if(dirsup==2){
			val->donnee=courant->donnee;
			pred->filsG=NULL;
		}else{
			//cas de la racine
			courant=NULL;
			free(courant);
			return 1;
		}
		//Dans le cas ou on est dans une feuille
		if(courant==racine){
			courant=NULL;
			free(courant);
			if(dirsup==1){
				pere->filsD=NULL;
			}else if(dirsup==2){
				pere->filsG=NULL;
			}
			return 0;
		}
		//Dans le cas ou on supprime un noeud au sein de l'arbre
		courant=NULL;
		free(courant);
		courant=racine;
		dirsup=dirold;
	}

	if(courant->filsG!=NULL){
		Sup_elem(courant->filsG,courant,2,valsup);
	}
	if(courant->filsD!=NULL){
		Sup_elem(courant->filsD,courant,1,valsup);
	}
	return 0;
}

/*void sup_sousarbre(Noeud *racine,int valsup){
  Noeud* courant=racine;
  Noeud* nwval;
  Noeud* prednwval=NULL;
  if(courant->donnee==valsup){

  }

  if(courant->filsG!=NULL){
    Sup_elem(courant->filsG,courant->donnee);
  }
  if(courant->filsD!=NULL){
    Sup_elem(courant->filsD,courant->donnee);
  }
  return;
}*/
