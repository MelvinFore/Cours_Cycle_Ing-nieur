#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include "arbre.h"
#include "fileabr.h"

File* creerNouvelleFile()
{
	File* nouvellefile=(File*) malloc(sizeof(File));
	if(nouvellefile==NULL){
		printf("Erreur : Impossible d'allouer de la mémoire pour la file.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvellefile->tete=NULL;
	return nouvellefile;
}

Element* creerNouvelElement(Noeud* valeur)
{
	Element* nouvelelement=(Element*) malloc(sizeof(Element));
	if(nouvelelement==NULL){
		printf("Erreur : Impossible d'allouer de la mémoire pour l'element.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvelelement->suivant=NULL;
	nouvelelement->donnee=valeur;
	return nouvelelement;
}

void est_videfile(File* file)
{
	if(file->tete==NULL){
		printf("La file est vide\n");
	}else{
		printf("La file est non vide\n");
	}
}

void enfilement(File* file,Noeud* valeur)
{
	Element* nouvelElement=creerNouvelElement(valeur);
	nouvelElement->suivant=file->tete;
	file->tete=nouvelElement;
}

//On parcourt la file jusqu'a sa fin pour supprimer son element le plus ancien
//Un pointeur vers la fin de la liste aurait été plus judicieux
Noeud* defilement(File* file)
{
	Noeud* valretour;
	if(file->tete==NULL)
	{
		printf("la file est deja vide\n");
		return 0;
	}
	Element* courant=file->tete;
	Element* pred=NULL;
	while(courant->suivant!=NULL)
	{
		pred=courant;
		courant=courant->suivant;
	}
	valretour=courant->donnee;
	//dans le cas ou l'on a qu une seule valeur
	if(pred==NULL)
	{
		file->tete=NULL;
	}else{
		pred->suivant=NULL;
	}
	free(courant);
	return valretour;
}
