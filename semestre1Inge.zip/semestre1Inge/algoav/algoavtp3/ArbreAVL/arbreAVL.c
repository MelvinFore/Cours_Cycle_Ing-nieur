#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbreAVL.h"
#include "parcours.h"

// Fonction pour créer un nouvel arbre
ArbreAVL* creerNouvelarbreAVL()
{
	ArbreAVL* nouvelarbre = (ArbreAVL*)malloc(sizeof(ArbreAVL));
	if (nouvelarbre == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour l'arbre.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvelarbre->racine = NULL;
	return nouvelarbre;
}

// Fonction pour créer un nouveaunoeud
Noeud* creerNoeud(int valeur)
{
	Noeud* nouveauNoeud = (Noeud*)malloc(sizeof(Noeud));
	if (nouveauNoeud == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour le noeud.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouveauNoeud->donnee = valeur;
	nouveauNoeud->filsG = NULL;
	nouveauNoeud->filsD = NULL;
	return nouveauNoeud;
}

bool est_vide(ArbreAVL* abr)
{
	if(abr->racine==NULL){
		return true;
	}else{
		return false;
	}
}

void appel_ajout(ArbreAVL* abr){
	AjoutElemArbreAVL(abr);
	lastCall(abr);
}

//Comme pour les arbre binaire de recherche, si notre valeur
//est superieur a celle du noeud on va a droite et dans le cas
//contraire vers la gauche
void AjoutElemArbreAVL(ArbreAVL* abr){
	Noeud* courant=abr->racine;
	//On cree la valeur à ajouter dans l'arbre
	int nwval;
	printf("veuillez indiquer une valeur: ");
	scanf("%d",&nwval);

	if(est_vide(abr)==true){
		abr->racine=creerNoeud(nwval);
		return;
	}
	while(1){
		if(nwval<courant->donnee){
			if(courant->filsG==NULL){
				courant->filsG=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsG;
			}
		}else if(nwval>courant->donnee){
			if(courant->filsD==NULL){
				courant->filsD=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsD;
			}
		} else{
			//comme on a pas deux valeurs egales dans notre arbre, on enregistre rien
			return;
		}
	}
}

/*

*
  *
    *

  *
*   *

*/
Noeud* rotationG(Noeud *racine,Noeud *valpred){
	Noeud *courant=racine->filsD;
	//On verfie si on se trouve a la racine
	if(valpred==NULL){
		racine->filsD=NULL;
		racine->filsD=courant->filsG;
		courant->filsG=racine;
		return courant;
	}else{
		racine->filsD=NULL;
		racine->filsD=courant->filsG;
		courant->filsG=racine;
		valpred->filsG=courant;
		return NULL;
	}
}

/*
    *
  *
*

  *
*   *

*/
Noeud* rotationD(Noeud *racine,Noeud *valpred){
	Noeud *courant=racine->filsG;
	if(valpred==NULL){
		racine->filsG=NULL;
		racine->filsG=courant->filsD;
		courant->filsD=racine;
		return courant;
	}else{
		racine->filsG=NULL;
		racine->filsG=courant->filsD;
		courant->filsD=racine;
		valpred->filsD=courant;
		return NULL;
	}
}

//Fonction qui suprrime l'arbre en partant des feuille vers la racine
Noeud* del(Noeud *racine){
	Noeud* courant=racine;
	if(courant==NULL){
		return NULL;
	}

	if(courant->filsG!=NULL){
		del(courant->filsG);
	}
	if(courant->filsD!=NULL){
		del(courant->filsD);
	}
	free(courant);
	return NULL;
}

//permet de vider le buffer de stdin
void viderBuffer()
{
	int c=0;
	while (c!= '\n' && c != EOF)
		c=getchar();
}

void Appel_sup_elem(ArbreAVL* abr,int valsup){
	if(sup_elem(abr->racine,NULL,valsup)){
		lastCall(abr);
	}
}

//On echange la valeur a supprimer avec les valeur les plus a droite possible, jusqu'a atteindre une feuille
int sup_elem(Noeud* racine,Noeud* Npred,int valsup){
	Noeud* courant=racine;
	if(courant->donnee>valsup){
		if(courant->filsG!=NULL){
			sup_elem(courant->filsG,courant,valsup);
		}else{
			//dans ce cas la valeur n'existe pas
			return 0;
		}
	}else if(courant->donnee<valsup){
		if(courant->filsD!=NULL){
			sup_elem(courant->filsD,courant,valsup);
		}else{
			//dans ce cas la valeur n'existe pas
			return 0;
		}
	}else{
		//cas ou on est dans le noeud contenant la valeur
		if(courant->filsG==NULL && courant->filsD==NULL){
			free(courant);
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=NULL;
				}else if(Npred->donnee<valsup){
					Npred->filsD=NULL;
				}
			}
		}else if(courant->filsG!=NULL && courant->filsD==NULL){
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=courant->filsG;
				}else if(Npred->donnee<valsup){
					Npred->filsD=courant->filsG;
				}
			}else{
				racine=courant->filsG;
			}
			free(courant);
		}else if(courant->filsG==NULL && courant->filsD!=NULL){
			if(Npred!=NULL){
				if(Npred->donnee>valsup){
					Npred->filsG=courant->filsD;
				}else if(Npred->donnee<valsup){
					Npred->filsD=courant->filsD;
				}
			}else{
				racine=courant->filsD;
			}
			free(courant);
		}else{
			Noeud* changeNode=courant;
			int dirsup=0;
			Npred=courant;
			courant=courant->filsD;
			//On recherche la valeur la plus petite du sous-arbre droit
			while(courant->filsG!=NULL){
				dirsup=1;
				Npred=courant;
				courant=courant->filsG;
			}
			if(dirsup==0){
				Npred->filsD=courant->filsD;
			}else{
				Npred->filsG=courant->filsD;
			}
			changeNode->donnee=courant->donnee;
			free(courant);
		}
		return 1;
	}
	return 1;
}
