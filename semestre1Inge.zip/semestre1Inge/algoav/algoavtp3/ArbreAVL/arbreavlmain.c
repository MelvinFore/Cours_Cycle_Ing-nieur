#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbreAVL.h"
#include "parcours.h"

int main(void){
	int continuer=1;
	ArbreAVL *abr=creerNouvelarbreAVL();
	while(continuer==1){
		appel_ajout(abr);
 		printf("tapez 1 pour continuer: ");
		scanf("%d",&continuer);
		printf("\n");
	}
	Depth_first(abr->racine,NULL);  
	Appel_sup_elem(abr,12);
	Depth_first(abr->racine,NULL);
	del(abr->racine);
	free(abr);
}
