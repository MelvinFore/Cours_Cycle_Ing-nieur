#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbreAVL.h"
#include "parcours.h"


//Fonction qui parcours la hauteur d'un arbre à partir d'un noeud fourni
int Arbrehauteur(Noeud* racine,int hauteur){
	Noeud* courant=racine;
	int valFdroit=0;
	int valFgauche=0;
	if(courant==NULL){
		return 0;
	}

	if(courant->filsG!=NULL){
		valFgauche=hauteur+1;
		valFgauche=Arbrehauteur(courant->filsG,valFgauche);
	}
	if(courant->filsD!=NULL){
		valFdroit=hauteur+1;
		valFdroit=Arbrehauteur(courant->filsD,valFdroit);
	}

	if(valFgauche==0 && valFdroit==0){
		return hauteur;
	}else if(valFgauche>=valFdroit){
		return valFgauche;
	}else{
		return valFdroit;
	}
}

//Fonction qui calcule les hauteur d'arbre à partir d'un Noeud
//et renvoie la difference entre la partie gauche et droite
//Partie gauche->negative
//Partie droite->positive
int degre(Noeud* racine){
	Noeud* courant=racine;
	int valFdroit=0;
	int valFgauche=0;
	if(courant==NULL){
		return 0;
	}

	if(courant->filsG!=NULL){
		valFgauche=Arbrehauteur(courant->filsG,1);
	}
	if(courant->filsD!=NULL){
		valFdroit=Arbrehauteur(courant->filsD,1);
	}
	//printf("degre de %d = %d\n",racine->donnee,valFdroit-valFgauche);
	return valFdroit-valFgauche;
}

//Fonction qui ratache la racine de l'arbre à l'equilibrage
void lastCall(ArbreAVL* abr){
	abr->racine=appelequilibrage(abr->racine);
}

//D'abord on parcours l'arbre puis à la remonté recursive on réequilibre
//depuis le bas de l'arbre vers le haut grace à cette methode
Noeud* appelequilibrage(Noeud *racine){
	Noeud* newracine;
	Noeud* courant=racine;

	//ces appels recursifs permettent de partir des noeud du graphe pour trouver les déséquilibres
	if(courant->filsG!=NULL){
		racine->filsG=newracine=appelequilibrage(courant->filsG);
	}
	if(courant->filsD!=NULL){
		racine->filsD=newracine=appelequilibrage(courant->filsD);
	}

	//a chaque noeud on verifie pour equilibrer
	newracine=equilibrage(racine,NULL);
	if(newracine!=NULL){
		racine=newracine;
	}
	return racine;
}

//Fonction qui effectue selon les differents cas les bonnes rotation
//pour réequilibrer l'arbre
Noeud* equilibrage(Noeud *racine,Noeud* valpred){
	Noeud* courant=racine;
	Noeud* nwr;
	if(courant==NULL){
		return NULL;
	}

	printf("%d==%d\n",courant->donnee,degre(racine));

	if(degre(racine)==2 && degre(racine->filsD)==-1){
		rotationD(racine->filsD,racine);
		nwr=rotationG(racine,valpred);
		if(valpred==NULL){
			return nwr;
		}
	}else if(degre(racine)==-2 && degre(racine->filsG)==1){
		rotationG(racine->filsG,racine);
		nwr=rotationD(racine,valpred);
		if(valpred==NULL){
			return nwr;
		}
	}else if(degre(racine)==-2){
		nwr=rotationD(racine,valpred);
		if(valpred==NULL){
			return nwr;
		}
	}else if(degre(racine)==2){
		nwr=rotationG(racine,valpred);
		if(valpred==NULL){
			return nwr;
		}
	}
	return NULL;
}

//Fonction de parcours en profondeurs deja vu, les noeud a gauche en priorite
void Depth_first(Noeud *racine,Noeud* valpred){
	Noeud* courant=racine;
	if(courant==NULL){
		return;
	}
	if(valpred==NULL){
		printf("(%d)\n",courant->donnee);
	}else{
		printf("(%d)->(%d)\n",valpred->donnee,courant->donnee);
	}

	if(courant->filsG!=NULL){
		Depth_first(courant->filsG,courant);
	}
	if(courant->filsD!=NULL){
		Depth_first(courant->filsD,courant);
	}
	return;
}
