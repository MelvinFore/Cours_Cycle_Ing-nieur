#ifndef TABINIT_H
#define TABINIT_H

//prototype de fonction
void randomizetab(int tab[], int taille);
void reloadtab(int tabvalorigine[],int tabvalcpy[],int taille);

#endif
