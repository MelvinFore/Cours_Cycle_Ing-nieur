#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "insertion.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

/*Fonction qui parcourt dans une première boucle un tableau de son début vers sa fin
a chaque iteration de cette boucle si la valeur à l'indice où l'on se trouve est inférieur
à la valeur situé à l'indice précédent on rentre dans une autre boucle où on échange les valeurs tant que
cette condition est vraie*/
void tri_insertion(int tab[], int taille)
{
  int j,tmp,i;
  for(j=1; j<taille;j++){
    i=j;
    while(tab[i]<tab[i-1]&&i>0){
        tmp=tab[i-1];
        tab[i-1]=tab[i];
        tab[i]=tmp;
        i--;
    }
  }
}

/*Complexité dans le pire des cas (toujours triée dans l'ordre décroissant)
dans ce cas la complexité sera de O(n²) car on parcourt le tableau n-1 fois dans la boucle j
et dans la boucle i on parcourt le tableau de i=1 jusque i=n-1 donc n fois*/
