#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include <sys/stat.h>
#include "tabinit.h"

//On parcourt chaque case du tableau pour affecter une valeur aléatoire à l'aide de la fonction rand
void randomizetab(int tab[],int taille){
  sleep(1);
  srand((unsigned) time(NULL));
  for(int i=0;i<taille;i++){
    tab[i]=rand()%100;
  }
}

void reloadtab(int tabvalorigine[],int tabvalcpy[],int taille){
  for(int i=0; i<taille;i++){
    tabvalcpy[i]=tabvalorigine[i];
  }
}
