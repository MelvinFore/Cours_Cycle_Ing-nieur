#ifndef SELECTION_H
#define SELECTION_H

//prototype de fonction
void tri_selection(int tab[], int taille);

#endif
