#ifndef RAPIDEUNIQV1_H
#define RAPIDEUNIQV1_H

//prototype de fonction
void rapideuniqv1(int tab[],int idDep, int idEnd);
int reorgatab(int tab[],int pivot,int idDep,int idEnd);
void tri_rapideuniqv1(int tab[],int taille);
int aleapivot(int tab[],int  idDep,int idEnd);
int swappivot(int tab[],int i,int j,int pivot);
void swap(int tab[],int i,int j);

#endif
