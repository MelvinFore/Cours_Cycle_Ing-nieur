#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "fusion.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

/*Fonction recusive où on divise notre tableau en deux et on renvoie chaque parti dans la fonction jusqu'à
ce que la taille de chaque sous-tableau soit 1
puis a la remontée on range dans le grand tableau non divisé les valeurs dans l'ordre croissant*/
void tri_fusion(int tab[], int taille)
{
  div_tab(tab,taille);
  return;
}

//Dans cette partie on divise notre tableau principal en deux autres
//recursivement jusqu'à avoir des sous-tableaux de taille 1
void div_tab(int tab[], int taille){
  int *gauche;
  int *droite;
  int tailleg;
  int tailled;
  if(taille>1){
    //Si le tableau principal est de taille pair les deux sous tableaux ont la même taille
    if(taille%2==0){
      gauche=(int*)malloc(sizeof(int)*(taille/2));
      droite=(int*)malloc(sizeof(int)*(taille/2));
      for(int x=0;x<taille/2;x++){
        gauche[x]=tab[x];
        droite[x]=tab[x+(taille/2)];
      }
      div_tab(gauche,(taille/2));
      div_tab(droite,(taille/2));
      tailleg=tailled=(taille/2);
    }else{
      //Dans ce cas un des deux sous tableaux sera plus grand que l'autre
      gauche=(int*)malloc(sizeof(int)*(taille/2));
      droite=(int*)malloc(sizeof(int)*((taille/2)+1));

      //on initialise les valeurs de chaque sous-tableau en meme temps
      for(int x=0;x<taille/2;x++){
        gauche[x]=tab[x];
        droite[x]=tab[x+(taille/2)];
      }
      //comme on est dans le cas impaire le tableau droite a une valeur en plus
      droite[(taille/2)]=tab[taille-1];

      div_tab(gauche,(taille/2));
      div_tab(droite,((taille/2)+1));
      tailleg=(taille/2);
      tailled=(taille/2)+1;
    }
    //Arrivé à ce stade on va commencer la remontée des sous-tableaux
    fusion(tab,gauche,droite,taille,tailleg,tailled);
    free(gauche);
    free(droite);
  }
}

//On effectue la remontée des sous-tableaux, durant celle-ci on place les valeurs de ceux de gauche en premiers
//dans le tableau principal puis apres les valeurs du tableau de droite
void fusion(int tab[], int gauche[],int droite[],int taille,int tailleg, int tailled){
  int i,ig=0,id=0;
  for(i=0;i<taille;i++){
    //si l'indice ig est supérieur à la taille de g c'est que ce tableau est vide, donc il ne reste des valeurs que
    //dans tabd
    if(ig>=tailleg){;
      tab[i]=droite[id];
      id++;
    }else if(id>=tailled){
      //inverse de la condition ci-dessus
      tab[i]=gauche[ig];
      ig++;
    }else{
      //les deux tableaux ne sont pas parcouru donc on selection la valeur la plus petite de chaque tableau
      //bien-sur ils ont chacun leur indice
      if(droite[id]<gauche[ig]){
        tab[i]=droite[id];
        id++;
      }else{
        tab[i]=gauche[ig];
        ig++;
      }
    }
  }
}

/* Dans mon algorithme la complexité doit être 2n*log(n), on a log(n) car on divise le tableau en 2 sous tableau à chaque iteration
et 2n car on insère les valeurs une 1er fois dans les sous-tableau et une deuxième fois de manière trié dans le tableau final*/
