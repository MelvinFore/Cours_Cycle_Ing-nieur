#ifndef BULLE_H
#define BULLE_H

//prototype de fonction
void tri_bulle(int tab[], int taille);

#endif
