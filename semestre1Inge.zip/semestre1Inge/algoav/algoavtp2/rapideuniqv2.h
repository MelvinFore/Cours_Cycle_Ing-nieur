#ifndef RAPIDEUNIQV2_H
#define RAPIDEUNIQV2_H

//prototype de fonction
void rapideuniqv2(int tab[],int idDep, int idEnd);
void tri_rapideuniqv2(int tab[],int taille);
int pivotmedian(int tab[],int idDep,int idEnd);

#endif
