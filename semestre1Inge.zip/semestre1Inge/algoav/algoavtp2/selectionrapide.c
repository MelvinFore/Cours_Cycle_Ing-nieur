#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "selectionrapide.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

//Dans cette version du tri à chaque iteration on recherche la valeur minimum et maximum
//pour pouvoir réduire le temps de tri
void tri_selection_rapide(int tab[], int taille){
  int demitab;
  int tmpmin,tmpmax,tmpswap;
  int idswapmin,idswapmax;
  int EoT=1;

  demitab=(taille/2);
  for(int i=0;i<demitab;i++){
    tmpmin=tab[i];
    idswapmin=i;
    tmpmax=tab[taille-EoT];
    idswapmax=taille-EoT;
    for(int x=i; x<=(taille-EoT);x++){
      if(tab[x]<tmpmin){
        tmpmin=tab[x];
        idswapmin=x;
      }
      if(tab[x]>tmpmax){
        tmpmax=tab[x];
        idswapmax=x;
      }
    }
    //phase d'échange des valeurs
    tmpswap=tab[i];
    tab[i]=tmpmin;
    tab[idswapmin]=tmpswap;

    if(idswapmax!=i){
      tmpswap=tab[taille-EoT];
      tab[taille-EoT]=tmpmax;
      tab[idswapmax]=tmpswap;
    }else{
      //Si la valeur a mettre dans la case de la valeur max, se situait dans la case de la valeur min
      //il faut donc échanger avec la case du tableau ou la valeur min à déjà effectué un échange
      //pour récupérer la valeur que l'on visait à l'origine
      tmpswap=tab[taille-EoT];
      tab[taille-EoT]=tmpmax;
      tab[idswapmin]=tmpswap;
    }
    EoT++;
  }
}

/*Dans le pire des cas (idem que pour la version classique)
On descend en complexité O(n²/4) car on divise le nombre d'iteration dans la première boucle par 2 et idem dans la seconde*/
