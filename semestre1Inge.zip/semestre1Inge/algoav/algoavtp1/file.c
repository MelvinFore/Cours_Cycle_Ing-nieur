#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

// Définition de la structure d'un element de la file
typedef struct Element
{
  int donnee;
  struct Element* suivant;
} Element;

// Définition de la structure de la file
typedef struct File
{
  Element* tete; // Pointeur vers le premier élément de la liste
} File;

File* creerNouvelleFile();
Element* creerNouvelElement(int valeur);
void est_vide(File* file);
void enfilement(File* file,int valeur);
int defilement(File* file);
void parcours(File* file);
void affrec(File*file,int cpt);
void FirstFileElem(File* file);
int countFile(File* file);
File* cpyFile(File* file);
File* concatFile(File* file1,File* file2);
void FreeFile(File * file);

int main(void)
{
  File* nwf=creerNouvelleFile();
  File* cpytest;
  File* testconcat;
  enfilement(nwf,817);
  defilement(nwf);
  printf("il y a %d elements\n",countFile(nwf));
  enfilement(nwf,0);
  enfilement(nwf,2);
  enfilement(nwf,7);
  cpytest=cpyFile(nwf);
  est_vide(nwf);
  testconcat=concatFile(nwf,cpytest);
  parcours(testconcat);
  FreeFile(nwf);
  FreeFile(cpytest);
  FreeFile(testconcat);
  est_vide(nwf);
  free(nwf);
  free(cpytest);
  free(testconcat);
}

File* creerNouvelleFile()
{
  File* nouvellefile=(File*) malloc(sizeof(File));
  if(nouvellefile==NULL){
    printf("Erreur : Impossible d'allouer de la mémoire pour la file.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvellefile->tete=NULL;
  return nouvellefile;
}

Element* creerNouvelElement(int valeur)
{
  Element* nouvelelement=(Element*) malloc(sizeof(Element));
  if(nouvelelement==NULL){
    printf("Erreur : Impossible d'allouer de la mémoire pour l'element.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelelement->suivant=NULL;
  nouvelelement->donnee=valeur;
  return nouvelelement;
}

void est_vide(File* file)
{
  if(file->tete==NULL){
    printf("La file est vide\n");
  }else{
    printf("La file est non vide\n");
  }
}

void enfilement(File* file,int valeur)
{
Element* nouvelElement=creerNouvelElement(valeur);
nouvelElement->suivant=file->tete;
file->tete=nouvelElement;
}

//On parcourt la file jusqu'a sa fin pour supprimer son element le plus ancien
//Un pointeur vers la fin de la liste aurait été plus judicieux
int defilement(File* file)
{
  int valretour;
  if(file->tete==NULL)
  {
    printf("la file est deja vide\n");
    return 0;
  }
  Element* courant=file->tete;
  Element* pred=NULL;
  while(courant->suivant!=NULL)
  {
  pred=courant;
  courant=courant->suivant;
  }
  valretour=courant->donnee;
  //dans le cas ou l'on a qu une seule valeur
  if(pred==NULL)
  {
    file->tete=NULL;
  }else{
    pred->suivant=NULL;
  }
  free(courant);
  return valretour;
}

void parcours(File* file)
{
  if(file->tete==NULL)
  {
    printf("la file est deja vide\n");
    return;
  }
  int cptcount=countFile(file);
  affrec(file,cptcount);
  printf("\n");
  return;
}

//pour ne pas afficher notre file de la plus ancienne valeur a la plus recente
//je decide de faire des appelles recursif pour ou j'effectue mon parcours en defilent et enfilent succesivement
//jusqu'a atteindre la taille de ma file
//Dans ce cas j'arrete et j'affiche la valeur du defilement, avec la remonte recursive ce sera de la valeur la plus recente a la plus ancienne
void affrec(File*file,int cpt){
  int valaff;
  if(cpt>0){
    valaff=defilement(file);
    enfilement(file,valaff);
    cpt--;
    affrec(file,cpt);
    printf("%d-",valaff);
  }
  return;
}

void FirstFileElem(File* file)
{
  if(file->tete==NULL)
  {
    printf("la file est deja vide\n");
    return;
  }

  Element* courant=file->tete;
  while(courant->suivant!=NULL)
  {
    courant=courant->suivant;
  }
  printf("le premier element entree dans la liste encore present est %d\n",courant->donnee);
  return;
}

File* cpyFile(File* file){
  File* filecpy=creerNouvelleFile();
  int cpt=countFile(file);
  int fileval;
  if(file!=NULL){
    while(cpt>0){
      fileval=defilement(file);
      enfilement(file,fileval);
      enfilement(filecpy,fileval);
      cpt--;
    }
  }
  return filecpy;
}

File* concatFile(File* file1,File* file2){
    File* fileconcat=creerNouvelleFile();
    int cpt=countFile(file1);
    int fileval;
    if(file1!=NULL){
      while(cpt>0){
        fileval=defilement(file1);
        enfilement(file1,fileval);
        enfilement(fileconcat,fileval);
        cpt--;
      }
    }
    cpt=countFile(file2);
    if(file2!=NULL){
      while(cpt>0){
        fileval=defilement(file2);
        enfilement(file2,fileval);
        enfilement(fileconcat,fileval);
        cpt--;
      }
    }
    return fileconcat;
}

void FreeFile(File* file)
{
  if(file->tete==NULL)
  {
    printf("la file est deja vide\n");
    return;
  }
  while(file->tete!=NULL)
  {
    defilement(file);
  }
  return;
}

//Fonction qui compte toute les valeurs d'une liste
//on defile notre liste dans un tampon, puis on réenfile nos valeurs dans la liste originel
int countFile(File* file)
{
	if(file->tete==NULL){
		return 0;
	}
  int cpt=0;
  int saveVal;
  Element *courante;
  File* filecount=creerNouvelleFile();
	while(file->tete!=NULL){
    courante=file->tete;
    saveVal=defilement(file);
    enfilement(filecount,saveVal);
    cpt++;
	}
  while(filecount->tete!=NULL){
    courante=filecount->tete;
    saveVal=defilement(filecount);
    enfilement(file,saveVal);
  }
  free(filecount);
	return cpt;
}
