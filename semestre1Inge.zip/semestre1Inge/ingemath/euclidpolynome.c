#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"liste.h"

/*Principe: le polynome de degre inferieur divise celui de degre superieur
des que le dividende est de degre inferieur au diviseur on arrete
on ajuste notre coefficiant au degre le plus haut du dividende*/
//On renvoie le reste
Liste* divpolynomeR(Liste* P1, Liste* P2){
  Liste* dividende;
  Liste* diviseur;
  Liste* reste;
  Liste* quotient;
  int degP1=countlist(P1)-1;
  int degP2=countlist(P2)-1;
  if(degP1>degP2){
    dividende=P1;
    diviseur=P2;
  }else{
    dividende=P2;
    diviseur=P1;
  }
  while(countlist(dividende)>=countlist(diviseur)){
    //

  }
}
//On renvoie le quotient
Liste* divpolynomeQ(Liste* P1, Liste* P2){

}

//les valeurs de depart de notre liste seront les degres les plus hauts du polynome gauche degre eleve droite degre faible
int main(void){
  //poly de degre 5
  Liste* poly1=creerNouvelleListe();
  //poly de degre 3
  Liste* poly2=creerNouvelleListe();
  Liste* test=creerNouvelleListe();
  //creation du premier polynome
  ajouterEnTete(poly1,-2);
  ajouterEnTete(poly1,-1);
  ajouterEnTete(poly1,2);
  ajouterEnTete(poly1,3);


  //creation du deuxime
  ajouterEnTete(poly2,1);
  ajouterEnTete(poly2,0);
  ajouterEnTete(poly2,1);

  parclist(poly1);
  parclist(poly2);

  cpylist(poly1,test);
  parclist(test);


  freelist(poly1);
  freelist(poly2);
  free(poly1);
  free(poly2);
  return 0;
}
