Rdef soustPoly(poly1, poly2, pZ):
    while len(poly1) < len(poly2):
        poly1.insert(0, 0)
    while len(poly2) < len(poly1):
        poly2.insert(0, 0)
    # Soustraction des coefficients des polynômes modulo pZ
    return [(a - b) % pZ for a, b in zip(poly1, poly2)]

def divPoly(R, Q, pZ):
    # Vérifier que le diviseur Q n'est pas le polynôme nul
    if not Q or Q[0] == 0:
        raise ValueError("Division par un polynôme nul")

    quotient = [0] * (len(R) - len(Q) + 1)
    while len(R) >= len(Q) and R[0] != 0:
        # Calculer le facteur du terme de tête pour la soustraction
        facteur = (R[0] * pow(Q[0], pZ - 2, pZ)) % pZ
        # Réduire le polynôme R
        reduction = [(coeff * facteur) % pZ for coeff in Q] + [0] * (len(R) - len(Q))
        R = soustPoly(R, reduction, pZ)
        while R and R[0] == 0:
            R.pop(0)
        if len(R) - len(Q) >= 0:
            quotient[len(R) - len(Q)] = facteur

    return quotient, R


 # Calcul du PGCD des polynômes
def pgcdPoly(poly1, poly2, pZ):
    while any(coeff != 0 for coeff in poly2):
        # Réduction de poly1 modulo poly2 jusqu'à ce que la longueur de poly1 soit inférieure
        while len(poly1) >= len(poly2) and any(coeff != 0 for coeff in poly1):
            # Calcul du facteur de réduction
            facteur = (poly1[0] * pow(poly2[0], pZ - 2, pZ)) % pZ
            # Réduction de poly1 par poly2
            reduction = [(coeff * facteur) % pZ for coeff in poly2] + [0] * (len(poly1) - len(poly2))
            poly1 = [(a - b) % pZ for a, b in zip(poly1, reduction)]
            # Élimination des zéros en tête de poly1
            while poly1 and poly1[0] == 0:
                poly1.pop(0)

        # Échanger poly1 et poly2 pour la prochaine itération
        poly1, poly2 = poly2, poly1

    return poly1 # Retour du PGCD

def multiPoly(poly1, poly2, pZ):
    # Initialiser le résultat avec des zéros
    resultat = [0] * (len(poly1) + len(poly2) - 1)
    # Multiplication de chaque terme de poly1 par chaque terme de poly2
    for i in range(len(poly1)):
        for j in range(len(poly2)):
            resultat[i + j] = (resultat[i + j] + poly1[i] * poly2[j]) % pZ
    return resultat

def euclideEtenduPoly(R, Q, pZ):
    # Initialiser U, V
    U, V, U1, V1 = [1], [0], [0], [1]

    # Itérer tant que Q n'est pas le polynôme nul
    while any(Q):
        # Diviser R par Q
        quotient, reste = divPoly(R, Q, pZ)

        # Mise à jour de R, Q pour la prochaine itération
        R, Q = Q, reste

        # Mise à jour de U, V, U1, V1
        U, U1 = U1, soustPoly(U, multiPoly(quotient, U1, pZ), pZ)
        V, V1 = V1, soustPoly(V, multiPoly(quotient, V1, pZ), pZ)

    return U, V


pZ = 5  # Nombre premier pour le corps fini Fp
poly1 = [1,3,3,1]
poly2 = [1,2,1]

pgcd = pgcdPoly(poly1, poly2, pZ)
U, V = euclideEtenduPoly(poly1,poly2, pZ)

# Question 1
print("Question 1")
print("Le PGCD des polynômes est :", pgcd)

# Question 2
print("Question 2")
print("U:", U)
print("V:", V)
