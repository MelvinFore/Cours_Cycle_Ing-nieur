#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure d'une cellule de la liste chaînée
typedef struct Cellule
{
int donnee;
struct Cellule* suivante;
struct Cellule* precedente;
} Cellule;

// Définition de la structure de la liste doublement chaînée
typedef struct Listedbc
{
Cellule* tete; // Pointeur vers le premier élément de la liste
} Listedbc;

Cellule* creerNouvelleCellule(int valeur);
Listedbc* creerNouvelleListedbc();
void est_vide(Listedbc* liste);
void ajouterEnTete(Listedbc* liste, int valeur);
void ajouterEnQueue(Listedbc* liste, int valeur);
void ajouterEnPosition(Listedbc* liste,int position, int valeur);
void supprimerElement(Listedbc* liste, int valeur);
void rechlistdbcval(Listedbc* liste,int valeur);
void parclistdbc(Listedbc* liste);
void parclistdbcsup(Listedbc* liste);
int countlistdbc(Listedbc* liste);
void freelistdbc(Listedbc* liste);
void viderBuffer();


int main(void){
  Listedbc* nwliste=creerNouvelleListedbc();
  ajouterEnTete(nwliste,7);
  ajouterEnTete(nwliste,14);
  ajouterEnTete(nwliste,41);
  ajouterEnTete(nwliste,25);
  printf("%d\n",countlistdbc(nwliste));
  ajouterEnTete(nwliste,2089);
  supprimerElement(nwliste,41);
  ajouterEnQueue(nwliste,7702);
  ajouterEnPosition(nwliste,2,45443);
  rechlistdbcval(nwliste,702);
  parclistdbc(nwliste);
  parclistdbcsup(nwliste);
  freelistdbc(nwliste);
  est_vide(nwliste);
  free(nwliste);
}



// Fonction pour créer une nouvelle cellule avec une valeur donnée
Cellule* creerNouvelleCellule(int valeur)
{
  Cellule* nouvelleCellule = (Cellule*)malloc(sizeof(Cellule));
  if (nouvelleCellule == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la cellule.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelleCellule->donnee = valeur;
  nouvelleCellule->suivante = NULL;
  nouvelleCellule->precedente = NULL;
  return nouvelleCellule;
}

// Fonction pour créer une nouvelle liste vide
Listedbc* creerNouvelleListedbc(int valeur)
{
  Listedbc* nouvelleListedbc = (Listedbc*)malloc(sizeof(Listedbc));
  if (nouvelleListedbc == NULL)
  {
    printf("Erreur : Impossible d'allouer de la mémoire pour la liste.\n");
    exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
  }
  nouvelleListedbc->tete = NULL;
  return nouvelleListedbc;
}

//Fonction qui indique si la liste est vide
void est_vide(Listedbc* liste){
  if(liste->tete==NULL){
    printf("La liste est vide\n");
  }else{
    printf("La liste est non vide\n");
  }
  return;
}

//Fonction
void ajouterEnTete(Listedbc* liste, int valeur)
{
    Cellule* nouvelleCellule=creerNouvelleCellule(valeur);
    nouvelleCellule->precedente=NULL;
    nouvelleCellule->suivante=liste->tete;
    liste->tete=nouvelleCellule;
    if(nouvelleCellule->suivante!=NULL){
      nouvelleCellule=nouvelleCellule->suivante;
      nouvelleCellule->precedente=liste->tete;
    }
    return;
}

//Fonction pour ajouter une cellule en queue de liste
void ajouterEnQueue(Listedbc* liste, int valeur)
{
	if(liste->tete==NULL){
		liste->tete=creerNouvelleCellule(valeur);
		return;
	}
	Cellule* courante=liste->tete;
  	Cellule* lien;
	while(courante->suivante!=NULL){
		courante=courante->suivante;
	}
	courante->suivante=creerNouvelleCellule(valeur);
  	lien=courante->suivante;
  	lien->precedente=courante;
	return;
}

//Fonction qui ajoute au sein d'une liste une nouvelle cellule à une position données, la cellule a la position données est decalée vers la droite et toute les autres cellules la suivant
void ajouterEnPosition(Listedbc* liste, int position, int valeur)
{
  int cpt=1;
  int limite=countlistdbc(liste);
  Cellule* courante=liste->tete;
  Cellule* pred1=NULL;
  Cellule* pred2=NULL;
  if(position<=0 || position>limite || liste->tete==NULL){
    printf("la position selectionnée ne se trouve pas dans la liste\n");
  }else if(position==1){
    ajouterEnTete(liste,valeur);
  }else {
    while(cpt<position-1){
      cpt++;
      courante=courante->suivante;
    }
    pred1=courante;
    pred2=pred1;
    courante=courante->suivante;
    pred1->suivante=creerNouvelleCellule(valeur);
    pred1=pred1->suivante;
    pred1->suivante=courante;
    courante->precedente=pred1;
    pred1->precedente=pred2;
  }
  return;
}

void supprimerElement(Listedbc* liste, int valeur) {
  Cellule* courante = liste->tete;
  Cellule* precedente = NULL;
  //on traite le cas ou la cellule a supprimer ce trouve au debut de la liste
  if (courante != NULL && courante->donnee == valeur) {
      liste->tete = courante->suivante;
      free(courante);
      return;
  }
  //On parcourt la liste jusqu'a ce qu'on trouve la valeur ou que la liste soit totalement parcourut
  while (courante != NULL && courante->donnee != valeur) {
    precedente = courante;
    courante = courante->suivante;
  }
  //si la cellule courante est null c'est que la valeur a supprimer n'est pas dans la liste
  if (courante == NULL) {
    printf("La valeur %d n'a pas été trouvée dans la liste.\n", valeur);
    return;
  }

  precedente->suivante = courante->suivante;
  free(courante);
  courante=precedente->suivante;
  courante->precedente=precedente;
}

//Fonction dans laquelle on indique une valeur et une liste, elle nous retournera toutes les positions de cette valeur au sein de la liste
void rechlistdbcval(Listedbc* liste,int valeur)
{
	bool trouve=false;
	int pos=1;
	if(liste->tete==NULL){
		printf("il n'y a pas de valeur dans la liste\n");
		return;
	}
	printf("maintenant on affichera les positions de la valeur %d  dans la liste en allant de 1 a la fin de la liste\n",valeur);
	Cellule* courante=liste->tete;
	while(courante!=NULL){
		if(courante->donnee==valeur){
			printf("%d ->",pos);
			trouve=true;
		}
		pos++;
		courante=courante->suivante;
	}
	printf("\n");
	if(trouve==false){
		printf("aucune occurence de la valeur dans la liste\n");
	}
	return;
}

//Fonction qui affiche toute les valeurs presente au sein d'une liste
void parclistdbc(Listedbc* liste){
  Cellule* courante=liste->tete;
  while(courante!=NULL){
    printf("%d-",courante->donnee);
    courante=courante->suivante;
  }
  printf("\n");
}

//Fonction qui compte toute les valeurs d'une liste
int countlistdbc(Listedbc* liste)
{
	if(liste->tete==NULL){
		return 0;
	}
	Cellule* courante=liste->tete;
	int cpt=0;
	while(courante!=NULL){
		cpt++;
		courante=courante->suivante;
	}
	return cpt;
}

//Fonction qui nous permet de parcourir la liste doublement chainées dans une position ou dans une autre selon la lettre qu'on decide d'indiquer, ou de quitter ce mode
void parclistdbcsup(Listedbc* liste){
  Cellule* courante=liste->tete;
  char direction;
  while(direction!='e'&&direction!='E'){
    printf("%d\n",courante->donnee);
    printf("veuillez indiquer 'q' pour aller a gauche 'd' pour aller a droite 'e' pour finir\n");
    scanf("%c",&direction);
    if(direction=='q'||direction=='Q'){
      if(courante->precedente==NULL){
          printf("fin de liste\n");
      }else{
        courante=courante->precedente;
      }
    }else if(direction=='d'||direction=='D'){
      if(courante->suivante==NULL){
          printf("fin de liste\n");
      }else{
        courante=courante->suivante;
      }
    }
    viderBuffer();
  }
  printf("\n");
}

//Fonction qui libere tout l'espace alloué pour les cellules d'une liste
void freelistdbc(Listedbc* liste){
  Cellule* courante=liste->tete;
  while(liste->tete!=NULL){
    courante=courante->suivante;
    free(liste->tete);
    liste->tete=courante;
  }
}

//permet de vider le buffer de stdin
void viderBuffer()
{
  int c=0;
  while (c!= '\n' && c != EOF)
    c=getchar();
}
