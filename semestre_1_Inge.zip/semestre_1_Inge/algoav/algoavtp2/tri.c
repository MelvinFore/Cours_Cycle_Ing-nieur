#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include <sys/stat.h>
#include "fusion.h"
#include "fusionunique.h"
#include "insertion.h"
#include "bulle.h"
#include "rapide.h"
#include "boustrophedon.h"
#include "selection.h"
#include "selectionrapide.h"
#include "tabinit.h"
#include "rapideuniqv1.h"
#include "rapideuniqv2.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

int sizetab(int **tabsave, int **tabuse);
void selectTri(int tab[],int tabvalorigine[],int taille);
void afftab(int tab[], int taille);
void calcMoyenne(double ** tab,int tailleL, int tailleC,int nb_essaie,int tailletab);
bool veriftricroissant(int tab[],int taille);
bool veriftridecroissant(int tab[],int taille);
void evaltri(int tab[], int tabvalorigine[],int taille);

int main(void)
{
  //INITIALISATION DU TABLEAU DE VALEURS
  int continuerTri=1;
  int changerTailleTab=0;
  int* tabvalorigine=NULL;
  int* tabtest=NULL;
  int tabtaille=sizetab(&tabvalorigine,&tabtest);
  randomizetab(tabvalorigine,tabtaille);
  //SELECTION DU TRI
  while(continuerTri==1){
    //On insert les valeurs du tableau random d'origine dans un autre pour pouvoir tester ces valeurs avec différents tris
    reloadtab(tabvalorigine,tabtest,tabtaille);
    selectTri(tabtest,tabvalorigine,tabtaille);
    //On demande à l'utilisateur s'il souhaite continuer d'utiliser notre programme
    printf("Pour continuer tapez 1: ");
    scanf("%d",&continuerTri);
    printf("\n");
    //On demande à l'utilisateur s'il souhaite modifier la taille de notre tableau de valeurs
    if(continuerTri==1){
      printf("Pour changer la taille du tableau tapez 1: ");
      scanf("%d",&changerTailleTab);
      printf("\n");
      if(changerTailleTab==1){
        tabtaille=sizetab(&tabvalorigine,&tabtest);
      }
      //On modifie les valeurs du tableau dans tous les cas
      randomizetab(tabvalorigine,tabtaille);
    }
  }
  free(tabvalorigine);
  free(tabtest);
  return 0;
}

//Fonction où on renseigne des pointeurs de tableaux pour pouvoir leur allouer de l'espace mémoire
//Elle permet notamment de pouvoir changer la taille de nos tableaux de valeurs dès qu'on le souhaite dans le programme
int sizetab(int** tabsave,int** tabuse){
  int tabtaille;

  //On vérifie que les tableaux dans auxquels on veut assigner de la mémoire soient bien NULL
  //sinon on libère l'espace leur étant déjà alloué
  if(*tabsave!=NULL && *tabuse!=NULL){
    free(*tabsave);
    free(*tabuse);
  }
  printf("veuillez indiquer la taille de tableau que vous souhaitez: ");
  scanf("%d",&tabtaille);
  if(tabtaille<=0){
    exit(0);
  }

  *tabsave=(int*)malloc(sizeof(int)*tabtaille);
  *tabuse=(int*)malloc(sizeof(int)*tabtaille);
  return tabtaille;
}

void selectTri(int tab[], int tabvalorigine[],int taille){

  int number=0;
  //Zone où un tri sera effectué individuellement
  printf("veuillez choisir un tri parmi:\n1=tri_insertion\n2=tri_fusion\n3=tri_bulle\n4=tri_boustrophedon\n5=tri_rapide\n6=tri_selection\n7=tri_selection_rapide\n8=trifusion à un seul tableau\n9=test de rapidité de tous les algorithmes\n");
  scanf("%d",&number);
  switch (number) {
    case 1:
      tri_insertion(tab, taille);
      break;
    case 2:
      tri_fusion(tab, taille);
      break;
    case 3:
      tri_bulle(tab, taille);
      break;
    case 4:
      tri_boustrophedon(tab,taille);
      break;
    case 5:
      tri_rapideuniqv2(tab, taille);
      break;
    case 6:
      tri_selection(tab, taille);
      break;
    case 7:
      tri_selection_rapide(tab, taille);
      break;
    case 8:
      tri_fusionUnique(tab,taille);
      break;
    case 9:
      evaltri(tab,tabvalorigine,taille);
      return;
    default:
      printf("veuillez selectionner un tri la prochaine fois\n");
      return;
  }
  //AFFICHAGE DES VALEURS
  afftab(tabvalorigine,taille);
  afftab(tab,taille);
  if(veriftricroissant(tab,taille)==true){
    printf("le tableau est trie\n");
  }
  return;
}

void evaltri(int tab[], int tabvalorigine[],int taille){
  //zone ou tous les tris sont effectués dans le but de déterminer les plus efficaces en terme de temps.
    clock_t debut;
    clock_t fin;
    int nbalgo=8;
    int nbtest;

    printf("veuillez indiquer le nombre de test que vous voulez realiser par trie\nLe nombre de test par algos sera egale à ");
    scanf("%d",&nbtest);
    printf("\n");
    if(nbtest<=0){
      return;
    }
    //on cree un dossier nommé data dans lequel on rangera les fichiers csv contenant les temps d'exécution de nos algorithmes
    mkdir( "data", 0755 );
    chdir( "data" );

    double **MoyTmps=malloc(nbalgo*sizeof(double));
    for(int i=0;i<nbalgo;i++){
      MoyTmps[i]=malloc(nbtest*sizeof(double));
    }

    for(int i=0;i<nbtest;i++){
      printf("tri_insertion\n");
      debut=clock();
      tri_insertion(tab, taille);
      fin=clock();
      MoyTmps[0][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_fusion\n");
      debut=clock();
      tri_fusionUnique(tab, taille);
      fin=clock();
      MoyTmps[1][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_bulle\n");
      debut=clock();
      tri_bulle(tab, taille);
      fin=clock();
      MoyTmps[2][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_bulle+\n");
      debut=clock();
      tri_boustrophedon(tab,taille);
      fin=clock();
      MoyTmps[3][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_rapide\n");
      debut=clock();
      tri_rapideuniqv1(tab, taille);
      fin=clock();
      MoyTmps[4][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_rapide+selection\n");
      debut=clock();
      tri_rapideuniqv2(tab, taille);
      fin=clock();
      MoyTmps[5][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_select\n");
      debut=clock();
      tri_selection(tab, taille);
      fin=clock();
      MoyTmps[6][i]=(double)(fin-debut)/CLOCKS_PER_SEC;
      reloadtab(tabvalorigine,tab,taille);

      printf("tri_select+\n");
      debut=clock();
      tri_selection_rapide(tab, taille);
      fin=clock();
      MoyTmps[7][i]=(double)(fin-debut)/CLOCKS_PER_SEC;

      randomizetab(tabvalorigine,taille);
      reloadtab(tabvalorigine,tab,taille);
    }
    calcMoyenne(MoyTmps,nbalgo,nbtest,nbtest,taille);
    for(int i=0;i<nbalgo;i++){
      free(MoyTmps[i]);
    }
    free(MoyTmps);
    chdir( ".." );
    return;
}

void calcMoyenne(double ** tab,int tailleL, int tailleC,int nb_essaie,int tailletab){
  FILE * file;
  //eval file size
  struct stat efs;
  char nomfile [][30]={
    "valtri.csv",
  };
  for (int i=0;i<tailleL;i++){
    for(int x=1;x<tailleC;x++){
      tab[i][0]=tab[i][0]+tab[i][x];
    }
    tab[i][0]=tab[i][0]/tailleC;
  }

    file = fopen( nomfile[0], "a" );
    stat(nomfile[0],&efs);
    if(efs.st_size==0){
      fprintf(file,"taille du tableau,nombre de teste,temps,insertion,tri_fusionUnique,tri_bulle,tri_boustrophedon,tri_rapide,tri_rapide+selection,tri_selection,tri_selection_rapide\n");
    }
    fprintf(file,"%d,%d,",tailletab,nb_essaie);
    for(int x=0;x<tailleL-1;x++){
      fprintf(file,"%2f,",tab[x][0]);
      if(x==tailleL-2){
          fprintf(file,"%2f",tab[x+1][0]);
      }
    }
    fprintf(file,"\n");
    fclose(file);
  return;
}

//On parcourt chaque case du tableau pour afficher leur valeur
void afftab(int tab[],int taille){
  for(int i=0;i<taille;i++){
    printf("%d|",tab[i]);
  }
  printf("\n\n");
}


bool veriftricroissant(int tab[],int taille){
  bool est_trie=true;
  for(int i=0;i<taille-1;i++){
    if(tab[i]>tab[i+1]){
      est_trie=false;
      break;
    }
  }
  return est_trie;
}

bool veriftridecroissant(int tab[],int taille){
  bool est_trie=true;
  for(int i=0;i<taille-1;i++){
    if(tab[i]<tab[i+1]){
      est_trie=false;
      break;
    }
  }
  return est_trie;
}
