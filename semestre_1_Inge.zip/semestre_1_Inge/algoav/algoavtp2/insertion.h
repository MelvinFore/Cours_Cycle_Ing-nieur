#ifndef INSERTION_H
#define INSERTION_H

//prototype de fonction
void tri_insertion(int tab[], int taille);
#endif
