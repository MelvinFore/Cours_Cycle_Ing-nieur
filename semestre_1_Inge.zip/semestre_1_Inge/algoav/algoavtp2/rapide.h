#ifndef RAPIDE_H
#define RAPIDE_H

void tri_rapide(int tab[], int taille);
void count_rapide(int tab[],int taille,int* gauche,int* droite,int pivot);
void insert_rapide(int tab[],int taille, int tabg[], int tabd[], int pivot);

#endif
