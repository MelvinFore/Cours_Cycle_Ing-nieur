#ifndef FUSION_H
#define FUSION_H

//prototype de fonction
void tri_fusion(int tab[], int taille);
void div_tab(int tab[], int taille);
void fusion(int tab[], int gauche[],int droite[],int taille,int tailleg, int tailled);

#endif
