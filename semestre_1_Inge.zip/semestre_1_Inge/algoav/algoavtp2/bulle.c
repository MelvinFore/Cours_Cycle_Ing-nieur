#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include "bulle.h"

// Définition du type booléen
typedef int bool;

#define false 0
#define true 1

//Fonction où l'on parcourt chaque case du tableau du début vers la fin
//on compare la valeur de la case i à la case i+1 si tab[i] plus grand que tab[i+1]
//on échange et on continue. Dès que le tour est terminé on recommence mais on parcourt le tableau
//en parcourant une case en moins à la fin, jusqu à ce qu'on est réduit ce nombre de case à parcourir à 0
void tri_bulle(int tab[],int taille)
{
  bool endswap;
  int i=taille;
  int tmp;
  for(i;i>0;i--){
    endswap=false;
    for(int j=0;j<(i-1);j++){
      if(tab[j]>tab[j+1]){
        tmp=tab[j];
        tab[j]=tab[j+1];
        tab[j+1]=tmp;
        endswap=true;
      }
    }
  if(endswap==false){
      break;
  }
  }
}

/* Dans le pire des cas(si les valeurs sont triées dans l'ordre décroissant)
On va avoir une complexité d'ordre O(n²) car on va parcourir n*(n-i) avec i augmentant à chaque tour de boucle 
*/
