#ifndef ARBREAVL_H
#define ARBREAVL_H

// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure de l'arbre
typedef struct Noeud
{
	int donnee;
	struct Noeud* filsG;
	struct Noeud* filsD;
} Noeud;

// Définition de la structure de l'arbre
typedef struct ArbreAVL
{
	Noeud* racine; // Pointeur vers le premier élément de la liste
} ArbreAVL;

//prototype de fonction
void appel_ajout(ArbreAVL* abr);
ArbreAVL* creerNouvelarbreAVL();
Noeud* creerNoeud(int valeur);
bool est_vide(ArbreAVL* abr);
void AjoutElemArbreAVL(ArbreAVL* abr);
void Appel_sup_elem(ArbreAVL* abr,int valsup);
int sup_elem(Noeud* racine,Noeud* Npred,int valsup);
Noeud* rotationD(Noeud *racine,Noeud *valpred);
Noeud* rotationG(Noeud *racine,Noeud *valpred);
Noeud* del(Noeud *racine);
void viderBuffer();

#endif
