#ifndef PARCOURS_H
#define PARCOURS_H


//prototype de fonction
Noeud* appelequilibrage(Noeud *abr);
void Depth_first(Noeud *racine,Noeud* valpred);
int Arbrehauteur(Noeud* racine,int hauteur);
Noeud* equilibrage(Noeud *racine,Noeud* valpred);
int degre(Noeud* racine);
void lastCall(ArbreAVL* abr);
#endif
