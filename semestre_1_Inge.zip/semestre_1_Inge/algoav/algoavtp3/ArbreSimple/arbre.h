#ifndef ARBRE_H
#define ARBRE_H

// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure de l'arbre
typedef struct Noeud
{
	int donnee;
	struct Noeud* filsG;
	struct Noeud* filsD;
} Noeud;

// Définition de la structure de l'arbre
typedef struct Arbre
{
	Noeud* racine; // Pointeur vers le premier élément de la liste
} Arbre;

//prototype de fonction
Arbre* creerNouvelarbre();
Noeud* creerNoeud(int valeur);
bool est_vide(Arbre* abr);
void ajoutelemArbre(Arbre* abr);
void AjoutElemAleaArbre(Arbre* abr);
Noeud* del(Noeud *racine);
void viderBuffer();

#endif
