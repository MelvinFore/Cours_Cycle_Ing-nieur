#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "arbre.h"
#include "fileabr.h"
#include "parcours.h"

// Fonction pour créer un nouvel arbre
Arbre* creerNouvelarbre()
{
Arbre* nouvelarbre = (Arbre*)malloc(sizeof(Arbre));
if (nouvelarbre == NULL)
{
printf("Erreur : Impossible d'allouer de la mémoire pour l'arbre.\n");
exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
}
nouvelarbre->racine = NULL;
return nouvelarbre;
}

// Fonction pour créer un nouveaunoeud
Noeud* creerNoeud(int valeur)
{
Noeud* nouveauNoeud = (Noeud*)malloc(sizeof(Noeud));
if (nouveauNoeud == NULL)
{
printf("Erreur : Impossible d'allouer de la mémoire pour le noeud.\n");
exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
}
nouveauNoeud->donnee = valeur;
nouveauNoeud->filsG = NULL;
nouveauNoeud->filsD = NULL;
return nouveauNoeud;
}

bool est_vide(Arbre* abr)
{
if(abr->racine==NULL){
return true;
}else{
return false;
}
}

void ajoutelemArbre(Arbre* abr){
	Noeud* courant=abr->racine;
	char direction;
	//On cree la valeur à ajouter dans l'arbre
	int nwval;
	printf("veuillez indiquer une valeur: ");
	scanf("%d",&nwval);
	viderBuffer();
	printf("\n");

	if(est_vide(abr)==true){
		abr->racine=creerNoeud(nwval);
		return;
	}

	while(direction!='e'&&direction!='E'){
		printf("%d\n",courant->donnee);
		printf("veuillez indiquer 'q' pour aller a gauche 'd' pour aller a droite 'e' pour abandonner\n");
		scanf("%c",&direction);
		if(direction=='q'||direction=='Q'){
			if(courant->filsG==NULL){
				courant->filsG=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsG;
			}
		}else if(direction=='d'||direction=='D'){
			if(courant->filsD==NULL){
				courant->filsD=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsD;
			}
		}
		viderBuffer();
	}
	return;
}

void AjoutElemAleaArbre(Arbre* abr){
	Noeud* courant=abr->racine;
	//On cree la valeur à ajouter dans l'arbre
	int nwval;
	printf("veuillez indiquer une valeur: ");
	scanf("%d",&nwval);

	if(est_vide(abr)==true){
		abr->racine=creerNoeud(nwval);
		return;
	}
	while(1){
		if(rand()%2==1){
			if(courant->filsG==NULL){
				courant->filsG=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsG;
			}
		}else{
			if(courant->filsD==NULL){
				courant->filsD=creerNoeud(nwval);
				return;
			}else{
				courant=courant->filsD;
			}
		}
	}
}

Noeud* del(Noeud *racine){
	Noeud* courant=racine;
	if(courant==NULL){
		return NULL;
	}

	if(courant->filsG!=NULL){
		del(courant->filsG);
	}
	if(courant->filsD!=NULL){
		del(courant->filsD);
	}
	free(courant);
	return NULL;
}

//permet de vider le buffer de stdin
void viderBuffer()
{
	int c=0;
	while (c!= '\n' && c != EOF)
		c=getchar();
}
