#ifndef ABRNODESTACK_H
#define ABRNODESTACK_H

typedef struct ElementNode{
	Noeud* donnee;
	struct ElementNode* suivant;
} ElementNode;

typedef struct StackN{
	ElementNode* tete;
}   StackN;

//prototype de fonction
ElementNode* creerNouvelElementN(Noeud* valeur);
StackN* creerNouvellePileN();
void est_videN(StackN* stk);
void empilerN(StackN* stk,Noeud* valeur);
Noeud* depilerN(StackN* stk);
int PileSizeN(StackN* stk);
void FreePileN(StackN* stk);

#endif
