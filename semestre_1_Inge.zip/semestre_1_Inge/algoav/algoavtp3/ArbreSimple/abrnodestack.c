#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "arbre.h"
#include "abrnodestack.h"

// Fonction pour créer une nouvelle cellule avec une valeur donnée
ElementNode* creerNouvelElementN(Noeud* valeur)
{
	ElementNode* nouvelElementN = (ElementNode*)malloc(sizeof(ElementNode));
	if (nouvelElementN == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour la element.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvelElementN->donnee = valeur;
	nouvelElementN->suivant = NULL;
	return nouvelElementN;
}


StackN* creerNouvellePileN()
{
	StackN* nouvellePileN = (StackN*)malloc(sizeof(StackN));
	if (nouvellePileN == NULL)
	{
		printf("Erreur : Impossible d'allouer de la mémoire pour la liste.\n");
		exit(1); // Quitte le programme en cas d'erreur d'allocation mémoire
	}
	nouvellePileN->tete = NULL;
	return nouvellePileN;
}

//Fonction qui verifie si la pile est vide
void est_videN(StackN* stk){
	if(stk->tete==NULL){
		printf("la pile est vide\n");
	}else{
		printf("la pile est non vide\n");
	}
	return;
}

//Fonction qui permet d'ajouter un nouvel element à la liste
void empilerN(StackN* stk,Noeud* valeur){
	ElementNode* NouvelElementN=creerNouvelElementN(valeur);
	NouvelElementN->suivant=stk->tete;
	stk->tete=NouvelElementN;
	return;
}

//Fonction qui permet d'enlever l'element du dessus de la pile
Noeud* depilerN(StackN* stk){
	Noeud* valeurElem;
	if(stk->tete==NULL){
		printf("Cela ne sert pas de depiler une pile vide\n");
		return NULL;
	}

	ElementNode* Courant=stk->tete;
	stk->tete=Courant->suivant;
	valeurElem=Courant->donnee;
	free(Courant);
	return valeurElem;
}

//Fonction qui depile notre Pile dans une autre tampon pour compter le nombre d'éléments
//Puis on depile le tampon dans notre Pile d'origine pour recuperer notre structure initial
int PileSizeN(StackN* stk)
{
	if(stk->tete==NULL)
	{
		return 0;
	}
	Noeud* valrecup;
	int cpt=0;
	StackN* tmp=creerNouvellePileN();
	while(stk->tete!=NULL){
		valrecup=depilerN(stk);
		empilerN(tmp,valrecup);
		cpt++;
	}
	while(tmp->tete!=NULL){
		valrecup=depilerN(tmp);
		empilerN(stk,valrecup);
	}
	free(tmp);
	return cpt;
}

//On depile la pile entiere si elle est non vide
void FreePileN(StackN* stk)
{
	if(stk->tete==NULL)
	{
		return;
	}
	while(stk->tete!=NULL){
		depilerN(stk);
	}
	return;
}
