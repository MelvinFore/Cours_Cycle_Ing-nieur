#ifndef PARCOURS_H
#define PARCOURS_H


//prototype de fonction
void Depth_first(Noeud *racine,Noeud* valpred);
void Breadth_First_Search(Noeud *racine);
int Arbrehauteur(Noeud* racine,int hauteur);
void Depth_firstIterative(Noeud *racine);
#endif
