#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>

int descripteurTubeSignal[2];

void signal_handler(int sig) {
    int fin = -1;
    write(descripteurTubeSignal[1], &fin, sizeof(int));
}

void processus_de_filtrage(int read_end) {
    int descripteurTube[2];
    int nombre_premier, nombre;

    // Lire le premier nombre (nombre premier pour filtrer)
    if (read(read_end, &nombre_premier, sizeof(int)) <= 0) {
        close(read_end);
        return;
    }
    if (nombre_premier == -1) {
        printf("0\n");
        exit(0);
    }

    printf("Premier: %d\n", nombre_premier);

    if (pipe(descripteurTube) == -1) {
        fprintf(stderr, "Erreur de création de tube.\n");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        fprintf(stderr, "Erreur de création du processus.\n");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Processus parent
        close(descripteurTube[0]);
        while (read(read_end, &nombre, sizeof(int)) > 0) {
            if (nombre % nombre_premier != 0) {
                write(descripteurTube[1], &nombre, sizeof(int));
            }
        }
        close(descripteurTube[1]);
        close(read_end);
        wait(NULL);
    } else {
        // Processus fils
        close(descripteurTube[1]);
        processus_de_filtrage(descripteurTube[0]);
    }
}

int main() {
    int max_nombre = 50000;

    if (pipe(descripteurTubeSignal) == -1) {
        fprintf(stderr, "Erreur de création de tube.\n");
        return EXIT_FAILURE;
    }
    signal(SIGINT, signal_handler);
    pid_t pid = fork();
    if (pid == -1) {
        fprintf(stderr, "Erreur de création du processus.\n");
        return EXIT_FAILURE;
    }

    if (pid > 0) {
        // Processus père
        close(descripteurTubeSignal[0]);
        for (int i = 2; i <= max_nombre; i++) {
            write(descripteurTubeSignal[1], &i, sizeof(int));
        }
        close(descripteurTubeSignal[1]);
        wait(NULL);
    } else {
        // Processus fils
        close(descripteurTubeSignal[1]);
        processus_de_filtrage(descripteurTubeSignal[0]);
    }

    return 0;
}
