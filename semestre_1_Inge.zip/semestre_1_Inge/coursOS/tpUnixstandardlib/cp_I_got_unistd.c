#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <fcntl.h>

int main(int argc,char *argv[]){
  if(argc==3){
    int fdS,fdC;
    int cpy0,cpy1;
    char c;
    cpy0=dup(0);
    close(0);
    fdS=open(argv[1],O_RDONLY);
    cpy1=dup(1);
    close(1);
    fdC=open(argv[2],O_CREAT|O_WRONLY,0777);
    while(read(0,&c,sizeof(char))){
      write(1,&c,sizeof(char));
    }
    close(fdS);
    dup(cpy0);
    close(fdC);
    dup(cpy1);
    close(cpy0);
    close(cpy1);
    printf("ça marche !!!!!!\n");
  }
}
