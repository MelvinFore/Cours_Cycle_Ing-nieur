//  Created by Gilles Dequen on 19/11/2023.//
#include<stdarg.h>
#include<stdio.h>

// Exemple de fonction variadique
int foo(int v, ...) {
    int x = 0;

    // --- déclaration de la liste de paramètres indéfinie
    va_list my_list_of_parameters;
    // ---

    // --- pointage au début de la liste indéfinie sur un
    // --- paramètre connu
    va_start(my_list_of_parameters, v);
    // ---

    while(v--) {

        // --- récupération du prochain paramètre
        x += va_arg(my_list_of_parameters, int);
        // ---

    }

    // --- terminaison processus de lecture de la liste indéfinie
    va_end(my_list_of_parameters);
    // ---

    return(x);
}

int main() {
    int i = 1;
    printf("out: %d\n", foo(3, 4, 5, 6));

    printf("out: %d\n", foo(5, i, i, i, i, i++));
    printf("out: %d\n", foo(5, i, i, i, i, ++i));
    return(0);
}
