#include <stdio.h>
int i=10;
f() { printf("%d\n",i++); }
g() { f(); fork(); f(); }
int main() { g(); g(); return(0); }
