#include <stdio.h>

int n = 8;
int main() {
  int i;
  FILE* fichier = NULL;
  fichier = fopen("test.txt", "a");

  fichier = fopen("test.txt", "r+");
  for(i = 0; i < n; i++) fork();
  fprintf(fichier,"%d\n",i);
  fclose(fichier);
  return(0);
}
