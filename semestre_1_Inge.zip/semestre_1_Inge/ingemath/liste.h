#ifndef LISTE_H
#define LISTE_H

// Définition du type booleen

typedef int bool;

#define false 0
#define true 1

// Définition de la structure d'une cellule de la liste chaînée
typedef struct Cellule
{
  int donnee;
  struct Cellule* suivante;
} Cellule;

// Définition de la structure de la liste chaînée
typedef struct Liste
{
  Cellule* tete; // Pointeur vers le premier élément de la liste
} Liste;

Cellule* creerNouvelleCellule(int valeur);
Liste* creerNouvelleListe();
void est_vide(Liste* liste);
void ajouterEnTete(Liste* liste, int valeur);
void ajouterEnQueue(Liste* liste, int valeur);
void ajouterEnPosition(Liste* liste,int position, int valeur);
void supprimerElement(Liste* liste, int valeur);
void rechlistval(Liste* liste,int valeur);
void rechlistpos(Liste* liste,int position);
void cpylist(Liste* oldl, Liste* nwl);
int countlist(Liste* liste);
void parclist(Liste* liste);
void freelist(Liste* liste);

#endif
